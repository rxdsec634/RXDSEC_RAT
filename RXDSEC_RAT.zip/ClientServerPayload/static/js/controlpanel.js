// Control Panel JavaScript Functionality

// Constants
const REFRESH_INTERVAL = 10000; // 10 seconds

// DOM Elements (to be assigned when document is loaded)
let deviceList;
let commandHistory;
let fileTransferHistory;
let commandForm;
let fileTransferForm;
let deviceStatusIndicator;

// Event Listeners
document.addEventListener('DOMContentLoaded', function() {
    // Check if we're on the dashboard page
    deviceList = document.getElementById('device-list');
    if (deviceList) {
        initializeDashboard();
    }
    
    // Check if we're on the device detail page
    commandHistory = document.getElementById('command-history');
    if (commandHistory) {
        initializeDeviceDetail();
    }
});

// Dashboard Page Functions
function initializeDashboard() {
    console.log('Initializing dashboard...');
    
    // Set up refresh interval for device list
    setInterval(refreshDeviceList, REFRESH_INTERVAL);
    
    // Initial refresh
    refreshDeviceList();
}

function refreshDeviceList() {
    // In a real implementation, this would make an AJAX call to get the latest devices
    // For this MVP, we'll just reload the device indicators
    
    const deviceStatusElements = document.querySelectorAll('.device-status');
    
    deviceStatusElements.forEach(element => {
        const lastSeen = new Date(element.dataset.lastSeen);
        const now = new Date();
        const diffMinutes = Math.floor((now - lastSeen) / (1000 * 60));
        
        if (diffMinutes < 2) {
            element.className = 'device-status badge bg-success';
            element.textContent = 'Online';
        } else {
            element.className = 'device-status badge bg-danger';
            element.textContent = 'Offline';
        }
    });
}

// Device Detail Page Functions
function initializeDeviceDetail() {
    console.log('Initializing device detail page...');
    
    // Get references to DOM elements
    commandForm = document.getElementById('command-form');
    fileTransferForm = document.getElementById('file-transfer-form');
    deviceStatusIndicator = document.getElementById('device-status-indicator');
    
    // Set up form submission handlers
    if (commandForm) {
        commandForm.addEventListener('submit', handleCommandSubmit);
    }
    
    if (fileTransferForm) {
        fileTransferForm.addEventListener('submit', handleFileTransferSubmit);
    }
    
    // Set up refresh interval for command history and device status
    setInterval(refreshDeviceDetail, REFRESH_INTERVAL);
    
    // Initial refresh
    refreshDeviceDetail();
}

function refreshDeviceDetail() {
    // Refresh the command history and file transfer history
    // In a real implementation, this would make an AJAX call
    // For this MVP, we'll just update the device status indicator
    
    if (deviceStatusIndicator) {
        const lastSeen = new Date(deviceStatusIndicator.dataset.lastSeen);
        const now = new Date();
        const diffMinutes = Math.floor((now - lastSeen) / (1000 * 60));
        
        if (diffMinutes < 2) {
            deviceStatusIndicator.className = 'badge bg-success';
            deviceStatusIndicator.textContent = 'Online';
        } else {
            deviceStatusIndicator.className = 'badge bg-danger';
            deviceStatusIndicator.textContent = 'Offline';
        }
    }
    
    // Add indicators for command results that have been updated
    const commandItems = document.querySelectorAll('.command-item');
    commandItems.forEach(item => {
        if (item.dataset.refreshed === 'false') {
            const status = item.querySelector('.command-status');
            if (status && status.textContent.trim() !== 'pending') {
                item.classList.add('bg-light');
                item.dataset.refreshed = 'true';
            }
        }
    });
}

function handleCommandSubmit(event) {
    // This is handled by the server using a normal form submission
    // But we could add validation here
    
    const commandInput = document.getElementById('command-input');
    if (!commandInput.value.trim()) {
        event.preventDefault();
        alert('Command cannot be empty');
        return false;
    }
    
    return true;
}

function handleFileTransferSubmit(event) {
    // This is handled by the server using a normal form submission
    // But we could add validation here
    
    const filePathInput = document.getElementById('file-path-input');
    if (!filePathInput.value.trim()) {
        event.preventDefault();
        alert('File path cannot be empty');
        return false;
    }
    
    return true;
}

// Utility Functions
function formatTimestamp(timestamp) {
    const date = new Date(timestamp);
    return date.toLocaleString();
}

function formatCommandStatus(status) {
    switch (status) {
        case 'pending':
            return '<span class="badge bg-warning">Pending</span>';
        case 'executed':
            return '<span class="badge bg-success">Executed</span>';
        case 'failed':
            return '<span class="badge bg-danger">Failed</span>';
        default:
            return '<span class="badge bg-secondary">Unknown</span>';
    }
}

function formatFileTransferStatus(status) {
    switch (status) {
        case 'pending':
            return '<span class="badge bg-warning">Pending</span>';
        case 'completed':
            return '<span class="badge bg-success">Completed</span>';
        case 'failed':
            return '<span class="badge bg-danger">Failed</span>';
        default:
            return '<span class="badge bg-secondary">Unknown</span>';
    }
}
