import os
import uuid
import hashlib
import logging
import base64
import secrets
import json
from datetime import datetime
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes, hmac
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

# Set up logging
logger = logging.getLogger(__name__)

def generate_device_id():
    """Generate a unique device ID using UUID and timestamp"""
    # Create a base for the device ID
    base = str(uuid.uuid4())
    timestamp = datetime.utcnow().timestamp()
    
    # Combine UUID and timestamp to create a more unique ID
    combined = f"{base}:{timestamp}"
    
    # Create a hash and encode it
    device_hash = hashlib.sha256(combined.encode()).digest()
    encoded_id = base64.urlsafe_b64encode(device_hash[:18]).decode()
    
    return encoded_id

def sanitize_command(command):
    """Basic sanitization of shell commands"""
    # This is a very basic implementation
    # In a real app, you would have more robust validation
    
    # Check for potentially dangerous commands
    dangerous_commands = [
        "rm -rf", "mkfs", "dd if=", ":(){ :|:& };:", "> /dev/sda",
        "chmod -R 777 /", "mv ~ /dev/null"
    ]
    
    for dangerous in dangerous_commands:
        if dangerous in command:
            logger.warning(f"Potentially dangerous command detected: {command}")
            return None
    
    return command

def is_valid_file_path(file_path):
    """Validate that a file path is reasonable and not potentially dangerous"""
    # Basic validation to prevent path traversal and other issues
    if not file_path or '..' in file_path:
        return False
    
    # Ensure path is not targeting system directories
    dangerous_paths = [
        '/etc', '/bin', '/sbin', '/usr/bin', '/usr/sbin',
        '/var/run', '/system', '/sys', '/proc'
    ]
    
    for path in dangerous_paths:
        if file_path.startswith(path):
            return False
    
    return True


class Encryption:
    """Provides end-to-end encryption capabilities for secure communications"""
    
    @staticmethod
    def generate_key(password, salt=None):
        """Generate a secure key from a password using PBKDF2"""
        if salt is None:
            salt = os.urandom(16)
        
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,  # 256 bits
            salt=salt,
            iterations=100000,
            backend=default_backend()
        )
        
        key = kdf.derive(password.encode() if isinstance(password, str) else password)
        return key, salt
    
    @staticmethod
    def encrypt(data, key):
        """Encrypt data using AES-256-GCM with authentication"""
        if isinstance(data, str):
            data = data.encode('utf-8')
        elif isinstance(data, dict) or isinstance(data, list):
            data = json.dumps(data).encode('utf-8')
        
        # Generate a random IV (initialization vector)
        iv = os.urandom(12)  # 96 bits for GCM mode
        
        # Create an encryptor object
        cipher = Cipher(
            algorithms.AES(key),
            modes.GCM(iv),
            backend=default_backend()
        )
        encryptor = cipher.encryptor()
        
        # Encrypt the data
        ciphertext = encryptor.update(data) + encryptor.finalize()
        
        # Return IV, ciphertext, and tag as base64 encoded strings
        result = {
            'iv': base64.b64encode(iv).decode('utf-8'),
            'ciphertext': base64.b64encode(ciphertext).decode('utf-8'),
            'tag': base64.b64encode(encryptor.tag).decode('utf-8')
        }
        
        return result
    
    @staticmethod
    def decrypt(encrypted_data, key):
        """Decrypt data encrypted with AES-256-GCM"""
        # Decode the base64 encoded strings
        iv = base64.b64decode(encrypted_data['iv'])
        ciphertext = base64.b64decode(encrypted_data['ciphertext'])
        tag = base64.b64decode(encrypted_data['tag'])
        
        # Create a decryptor object
        cipher = Cipher(
            algorithms.AES(key),
            modes.GCM(iv, tag),
            backend=default_backend()
        )
        decryptor = cipher.decryptor()
        
        # Decrypt the data
        try:
            decrypted_data = decryptor.update(ciphertext) + decryptor.finalize()
            # Try to decode as JSON
            try:
                return json.loads(decrypted_data)
            except json.JSONDecodeError:
                # Not JSON, return as string if possible
                try:
                    return decrypted_data.decode('utf-8')
                except UnicodeDecodeError:
                    # Binary data
                    return decrypted_data
        except Exception as e:
            # Authentication failed
            logger.error(f"Decryption failed: {str(e)}")
            raise ValueError(f"Decryption failed: {str(e)}")
    
    @staticmethod
    def generate_secure_token():
        """Generate a secure random token for communication authentication"""
        return secrets.token_hex(32)  # 256 bits of randomness
    
    @staticmethod
    def compute_hmac(key, message):
        """Compute HMAC for message authentication"""
        if isinstance(message, str):
            message = message.encode('utf-8')
        elif isinstance(message, dict) or isinstance(message, list):
            message = json.dumps(message).encode('utf-8')
        
        h = hmac.HMAC(key, hashes.SHA256(), backend=default_backend())
        h.update(message)
        return base64.b64encode(h.finalize()).decode('utf-8')
    
    @staticmethod
    def verify_hmac(key, message, signature):
        """Verify HMAC signature"""
        computed_sig = Encryption.compute_hmac(key, message)
        return secrets.compare_digest(computed_sig, signature)
        
    @staticmethod
    def secure_data_with_hmac(data, key):
        """Encrypt data and add HMAC for authentication"""
        encrypted = Encryption.encrypt(data, key)
        encrypted_json = json.dumps(encrypted)
        hmac_signature = Encryption.compute_hmac(key, encrypted_json)
        
        return {
            'data': encrypted,
            'hmac': hmac_signature
        }
    
    @staticmethod
    def verify_and_decrypt(secure_data, key):
        """Verify HMAC signature and decrypt data"""
        encrypted = secure_data['data']
        signature = secure_data['hmac']
        
        # Verify HMAC
        encrypted_json = json.dumps(encrypted)
        if not Encryption.verify_hmac(key, encrypted_json, signature):
            raise ValueError("HMAC verification failed")
        
        # Decrypt data
        return Encryption.decrypt(encrypted, key)
