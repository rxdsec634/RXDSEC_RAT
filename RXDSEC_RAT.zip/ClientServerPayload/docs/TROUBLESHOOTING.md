# RXDSEC RAT Troubleshooting Guide

This document provides solutions for common issues you might encounter when working with RXDSEC RAT.

## Table of Contents
- [Server Issues](#server-issues)
- [Client Issues](#client-issues)
- [Connection Problems](#connection-problems)
- [Database Issues](#database-issues)
- [APK Binding Issues](#apk-binding-issues)
- [Surveillance Feature Issues](#surveillance-feature-issues)
- [Security and Anti-Detection Issues](#security-and-anti-detection-issues)

## Server Issues

### Server Won't Start

**Symptoms**:
- Error when running `python main.py`
- Server crashes immediately after starting
- Gunicorn worker failures

**Possible Causes and Solutions**:

1. **Port Conflict**
   - **Cause**: Another application is using port 5000
   - **Solution**: Check for port usage with `netstat -tuln | grep 5000` and either stop the other application or change the port in `main.py`

2. **Missing Dependencies**
   - **Cause**: Required packages are not installed
   - **Solution**: Run `pip install -r requirements.txt` to install all dependencies

3. **Database Configuration Issues**
   - **Cause**: Incorrect database URI or missing database
   - **Solution**: Verify your `.env` file has the correct `DATABASE_URL`. For SQLite, ensure the directory exists.

4. **Python Version**
   - **Cause**: Using incompatible Python version
   - **Solution**: Ensure you're using Python 3.11 or higher

5. **Memory Issues**
   - **Cause**: Insufficient system memory
   - **Solution**: Increase available memory or reduce the number of Gunicorn workers

### Web Interface Not Loading

**Symptoms**:
- Browser shows "Cannot connect to server"
- Blank page or 404 error
- Static assets not loading

**Possible Causes and Solutions**:

1. **Server Not Running**
   - **Solution**: Verify the server is running with `ps aux | grep python`

2. **Network/Firewall Issues**
   - **Solution**: Check firewall settings to ensure port 5000 is allowed

3. **Wrong URL**
   - **Solution**: Ensure you're using the correct URL (including port if needed)

4. **Static Files Issue**
   - **Solution**: Check permissions on the `static` directory

## Client Issues

### Client Won't Connect

**Symptoms**:
- Client shows connection errors
- Device never appears in the dashboard
- Repeated registration attempts

**Possible Causes and Solutions**:

1. **Incorrect Server URL**
   - **Solution**: Verify the server URL is correct and includes protocol, host, and port

2. **Network Restrictions**
   - **Solution**: Check if the device can reach the server (try `ping` or `curl`)
   - **Solution**: Verify the device has internet permission in Android

3. **Authentication Failure**
   - **Solution**: Delete any stored client data and try re-registering

4. **SSL Certificate Issues**
   - **Cause**: Self-signed or invalid certificates with secure connections
   - **Solution**: Add certificate to trusted store or temporarily use `--insecure` option

### Permissions Issues on Android

**Symptoms**:
- Features like camera or SMS access don't work
- Error messages about missing permissions
- Crashes when accessing protected features

**Possible Causes and Solutions**:

1. **Missing Runtime Permissions**
   - **Solution**: Request permissions manually on the device before use
   - **Solution**: For bound APKs, ensure the original app has the needed permissions

2. **Android Version Restrictions**
   - **Cause**: Android 10+ has restricted background access to resources
   - **Solution**: Use foreground service with notification or root methods

3. **OEM Restrictions**
   - **Cause**: Some device manufacturers add additional security layers
   - **Solution**: Check for manufacturer-specific settings that block background services

## Connection Problems

### Intermittent Connections

**Symptoms**:
- Device appears online/offline repeatedly
- Commands fail to execute consistently
- Heartbeat failures

**Possible Causes and Solutions**:

1. **Network Instability**
   - **Solution**: Increase heartbeat interval for more tolerance
   - **Solution**: Implement more robust reconnection logic

2. **Battery Optimization**
   - **Cause**: Android battery optimizations killing background processes
   - **Solution**: Disable battery optimization for the client app
   - **Solution**: Use foreground services with wake locks

3. **Server Timeout**
   - **Solution**: Adjust server connection timeouts
   - **Solution**: Implement load balancing for high traffic

### Slow Command Execution

**Symptoms**:
- Long delays between sending commands and execution
- Command status remains "pending" for extended periods

**Possible Causes and Solutions**:

1. **Client Polling Interval**
   - **Solution**: Reduce the polling interval for command checks

2. **Server Load**
   - **Solution**: Optimize database queries
   - **Solution**: Add server resources or implement caching

3. **Network Latency**
   - **Solution**: Use a server geographically closer to clients
   - **Solution**: Compress command data for faster transmission

## Database Issues

### Database Connection Failures

**Symptoms**:
- Server crashes with database-related errors
- "Cannot connect to database" errors
- SQLAlchemy exceptions

**Possible Causes and Solutions**:

1. **PostgreSQL Connection Issues**
   - **Solution**: Verify PostgreSQL is running with `systemctl status postgresql`
   - **Solution**: Check connection parameters in `DATABASE_URL`
   - **Solution**: Ensure the database user has proper permissions

2. **SQLite Access Issues**
   - **Solution**: Check permissions on the SQLite file and directory
   - **Solution**: Verify the path exists and is writable

3. **Connection Pool Exhaustion**
   - **Solution**: Configure SQLAlchemy engine options for proper pool recycling
   - **Solution**: Add `pool_recycle=300` and `pool_pre_ping=True` to engine options

### Data Integrity Issues

**Symptoms**:
- Inconsistent data in the dashboard
- Missing command results
- File transfer failures

**Possible Causes and Solutions**:

1. **Transaction Management**
   - **Solution**: Ensure proper transaction handling with commits and rollbacks
   - **Solution**: Implement retry logic for failed transactions

2. **Concurrent Access**
   - **Solution**: Use proper locking mechanisms
   - **Solution**: Implement optimistic concurrency control

3. **Database Corruption (SQLite)**
   - **Solution**: Backup and recreate the database
   - **Solution**: Migrate to PostgreSQL for better reliability

## APK Binding Issues

### Binding Process Failures

**Symptoms**:
- APK binding process fails
- Error messages during decompilation or recompilation
- Generated APK doesn't work

**Possible Causes and Solutions**:

1. **Incompatible Target APK**
   - **Cause**: Target APK uses unsupported features
   - **Solution**: Try a different target APK
   - **Solution**: Check the APK's SDK version and obfuscation level

2. **Missing Dependencies**
   - **Solution**: Ensure all APK binding dependencies are installed
   - **Solution**: Check for Java and Android SDK requirements

3. **Insufficient Resources**
   - **Cause**: APK binding requires significant memory and CPU
   - **Solution**: Increase available resources or try on a more powerful machine

### Bound APK Installation Issues

**Symptoms**:
- "App not installed" errors
- Installation completes but app crashes immediately
- Signature verification failures

**Possible Causes and Solutions**:

1. **Signing Issues**
   - **Solution**: Verify the APK is correctly signed
   - **Solution**: Try using a different signing key

2. **Target Device Incompatibility**
   - **Cause**: Bound APK requires features not available on target
   - **Solution**: Check minimum API level requirements

3. **Package Name Conflicts**
   - **Cause**: App with same package name already installed
   - **Solution**: Uninstall existing app or modify package name during binding

## Surveillance Feature Issues

### Camera or Microphone Access Failures

**Symptoms**:
- Camera/microphone commands fail
- "Access denied" or similar errors
- Empty or corrupted media files

**Possible Causes and Solutions**:

1. **Permission Issues**
   - **Solution**: Verify the app has camera and microphone permissions
   - **Solution**: Ensure permissions are granted at runtime

2. **Hardware Access**
   - **Cause**: Another app is using the camera/microphone
   - **Solution**: Release hardware properly after use

3. **Format Compatibility**
   - **Solution**: Use widely supported formats (JPEG for images, MP3 for audio)
   - **Solution**: Adjust encoding parameters for device compatibility

### SMS or Call Log Access Issues

**Symptoms**:
- SMS collection fails
- Call logs are incomplete
- Permission denied errors

**Possible Causes and Solutions**:

1. **Android Restrictions**
   - **Cause**: Android 10+ restricts SMS and call log access
   - **Solution**: Use default SMS app mechanism or root methods
   - **Solution**: Implement accessibility service alternative

2. **Content Provider Changes**
   - **Cause**: OEM modifications to standard content providers
   - **Solution**: Implement device-specific content provider paths
   - **Solution**: Add fallback methods for different Android versions

### Location Tracking Issues

**Symptoms**:
- No location data received
- Highly inaccurate locations
- Intermittent updates

**Possible Causes and Solutions**:

1. **GPS Disabled**
   - **Solution**: Request user to enable GPS
   - **Solution**: Use network-based location as fallback

2. **Indoor Environment**
   - **Cause**: Poor GPS signal indoors
   - **Solution**: Use WiFi and cellular positioning
   - **Solution**: Reduce accuracy requirements

3. **Background Restrictions**
   - **Cause**: Android limits background location access
   - **Solution**: Use foreground service with notification
   - **Solution**: Reduce frequency of location requests

## Security and Anti-Detection Issues

### Client Detection by Antivirus

**Symptoms**:
- Client is flagged by security software
- Automatic removal of client
- Alerts or notifications on device

**Possible Causes and Solutions**:

1. **Signature Detection**
   - **Solution**: Modify payload to avoid signature matching
   - **Solution**: Use APK binding with legitimate applications
   - **Solution**: Implement runtime code loading

2. **Behavior Detection**
   - **Solution**: Modify behavior patterns to be less suspicious
   - **Solution**: Spread operations over time
   - **Solution**: Reduce resource usage

3. **Heuristic Detection**
   - **Solution**: Implement additional anti-detection techniques
   - **Solution**: Use encryption for all stored files
   - **Solution**: Implement custom obfuscation

### Client Visibility to User

**Symptoms**:
- Client appears in app drawer despite hiding
- Visible notifications or processes
- Battery usage alerts

**Possible Causes and Solutions**:

1. **Incomplete Hiding Implementation**
   - **Solution**: Use more comprehensive app hiding techniques
   - **Solution**: Implement service-based operation without activities

2. **Battery Optimization Warnings**
   - **Solution**: Reduce resource usage
   - **Solution**: Implement smarter scheduling of operations

3. **Process Visibility**
   - **Solution**: Use innocuous process names
   - **Solution**: Implement root-based process hiding techniques

### Encryption or Authentication Failures

**Symptoms**:
- "Invalid token" errors
- "Decryption failed" messages
- Connection rejected by server

**Possible Causes and Solutions**:

1. **Key Mismatch**
   - **Solution**: Reset client encryption keys
   - **Solution**: Re-register device with server

2. **Time Synchronization Issues**
   - **Cause**: Device and server clocks are out of sync
   - **Solution**: Implement time tolerance in token verification
   - **Solution**: Use server time as reference

3. **Transmission Errors**
   - **Solution**: Implement better error handling and retries
   - **Solution**: Add integrity verification for all messages

## Advanced Troubleshooting

### Diagnostic Mode

For complex issues, enable diagnostic mode:

1. Server: Add `DIAGNOSTIC_MODE=True` to `.env` file
2. Client: Run with `--diagnostic` flag

This will produce detailed logs that can help identify the root cause of problems.

### Log Collection

To collect comprehensive logs for troubleshooting:

```bash
# Server logs
python collect_logs.py --server --days 3 --output server_logs.zip

# Client logs
python android_client.py --dump-logs --output client_logs.zip
```

### Community Support

For issues not covered in this guide, please reach out to the community:

- Check the [GitHub Issues](https://github.com/rxdsec/rxdsec-rat/issues)
- Join the Telegram group: [@Rxdsec](https://t.me/rxdsec)
- Search the knowledge base on the project wiki