# APK Payload Generation Guide

This document explains the APK payload generation capabilities of RXDSEC RAT, including the binding process, customization options, and deployment strategies.

## Table of Contents
- [Overview](#overview)
- [Prerequisites](#prerequisites)
- [APK Binding Process](#apk-binding-process)
- [Payload Customization](#payload-customization)
- [Advanced Options](#advanced-options)
- [Troubleshooting](#troubleshooting)

## Overview

RXDSEC RAT includes a powerful APK binding feature that allows you to:
1. Inject the RXDSEC RAT payload into legitimate Android applications
2. Create standalone APK payloads for direct installation
3. Customize the behavior and capabilities of the payload
4. Generate payloads compatible with various Android versions (5.0/API 21 through 15/API 35)

The APK generation system uses a combination of `androguard`, `apkutils3`, `apktool`, and other related libraries to decompile, modify, and recompile Android applications.

## Prerequisites

To use the APK payload generation features, ensure your system has:

1. **Required Python Packages** (all included in `requirements_full.txt`):
   - androguard
   - apkutils3
   - apktool
   - smali/baksmali
   - zipalign-android

2. **External Dependencies**:
   - JDK 8 or higher
   - Android SDK Build Tools (for APK signing)
   - At least 2GB RAM for the binding process

3. **Target APK** (for binding only):
   - A legitimate APK file
   - Preferably a commonly used application
   - Must be unprotected (no advanced obfuscation or packing)

## APK Binding Process

### Step 1: Preparing the Environment

1. Access the APK Binding page from the RXDSEC RAT dashboard
2. Ensure all dependencies are correctly installed
3. Upload or select a legitimate APK as the base application

### Step 2: Configuring the Payload

1. Specify payload options (described in detail in [Payload Customization](#payload-customization))
2. Choose target Android version compatibility
3. Select persistence and hiding mechanisms

### Step 3: Generating the Bound APK

1. Initiate the binding process
2. The system will:
   - Decompile the target APK
   - Identify injection points
   - Modify the AndroidManifest.xml
   - Inject payload code
   - Add necessary resources and libraries
   - Recompile the APK
   - Sign the modified APK

### Step 4: Downloading and Deployment

1. Download the generated APK
2. Transfer to the target device
3. Install via direct APK installation or through an app store (if possible)

## Payload Customization

The APK payload generator offers extensive customization options:

### Basic Options

| Option | Description |
|--------|-------------|
| **Payload Name** | Custom name for the payload (visible in logs) |
| **Target Server** | C2 server address for payload to connect to |
| **Connection Interval** | How often the payload connects to the server |
| **Initial Delay** | Time to wait before first connection attempt |

### Anti-Detection Options

| Option | Description |
|--------|-------------|
| **Hide Application Icon** | Remove app from launcher |
| **Process Hiding** | Hide process from task managers |
| **Anti-Emulator** | Detect and evade emulators |
| **Anti-Debugging** | Prevent analysis and debugging |
| **String Encryption** | Encrypt strings to avoid signature detection |
| **Sandbox Detection** | Detect and evade security sandboxes |
| **Timing Modifications** | Adjust timing to evade behavioral analysis |

### Persistence Methods

| Method | Description | Android Compatibility |
|--------|-------------|----------------------|
| **Boot Receiver** | Start at device boot | All versions |
| **Alarm Manager** | Schedule periodic restarts | All versions |
| **Job Scheduler** | Advanced scheduling | Android 5.0+ |
| **WorkManager** | Modern background processing | Android 8.0+ |
| **Foreground Service** | Persistent foreground operation | All versions |
| **System Service Binding** | Bind to system services | Android 5.0+ (requires root) |
| **Multiple Methods** | Combine various techniques | All versions |

### Surveillance Capabilities

| Capability | Description | Permission Requirements |
|------------|-------------|-----------------------|
| **Camera Access** | Remote camera capture | Camera permission |
| **Microphone Access** | Audio recording | Record Audio permission |
| **Location Tracking** | GPS/network location | Location permissions |
| **SMS Interception** | Read/monitor SMS messages | SMS permissions |
| **Call Logging** | Monitor phone calls | Phone state permission |
| **Contact Extraction** | Access contact list | Contacts permission |
| **Screen Capture** | Capture device screen | Accessibility or root |
| **Keylogging** | Record keystrokes | Accessibility service |

## Advanced Options

### Custom Code Injection

Advanced users can specify custom code to inject into the target application:

1. **Custom Startup Logic**:
   ```java
   // Example of custom startup logic
   public void onCustomStartup() {
       // Your code here
       executeCustomFunction();
       collectAdditionalData();
   }
   ```

2. **Custom Persistence Rules**:
   ```xml
   <!-- Example of custom component in AndroidManifest.xml -->
   <receiver android:name=".CustomBootReceiver">
       <intent-filter>
           <action android:name="android.intent.action.BOOT_COMPLETED" />
       </intent-filter>
   </receiver>
   ```

3. **Custom Payload Behavior**:
   - Event-based triggers
   - Conditional execution
   - Environment-specific behaviors

### Multi-Stage Payloads

The APK binding system supports multi-stage payloads:

1. **Stage 1**: Initial minimal payload for evasion
2. **Stage 2**: Full capability download after verification
3. **Stage 3**: Advanced modules loaded on demand

This approach reduces the initial footprint and improves evasion capabilities.

### Signature Manipulation

The payload generator can manipulate APK signatures:

1. **Certificate Cloning**: Mimic certificates of known applications
2. **Custom Signatures**: Apply user-provided signing keys
3. **Metadata Adjustment**: Modify package metadata to avoid detection

## Troubleshooting

### Common Issues

1. **Binding Failures**:
   - Verify the target APK is not obfuscated or protected
   - Check for sufficient disk space and memory
   - Try with a different target APK

2. **Installation Issues**:
   - Ensure "Install from unknown sources" is enabled
   - Check for signature verification errors
   - Verify minimum Android version compatibility

3. **Runtime Failures**:
   - Check logs for permission issues
   - Verify target device meets minimum requirements
   - Ensure network connectivity to C2 server

### Compatibility Matrix

| Feature | Android 5-7 | Android 8-10 | Android 11-13 | Android 14-15 |
|---------|------------|--------------|---------------|---------------|
| App Hiding | ✓ | ✓ | ✓ (Limited) | ✓ (Root only) |
| Boot Persistence | ✓ | ✓ | ✓ (Limited) | ✓ (Limited) |
| Camera Access | ✓ | ✓ | ✓ | ✓ (Requires user) |
| SMS Interception | ✓ | ✓ | ✓ (Default SMS app) | ✓ (Default SMS app) |
| Screen Capture | ✓ | ✓ | ✓ (Accessibility) | ✓ (Accessibility) |
| Keylogging | ✓ | ✓ | ✓ (Accessibility) | ✓ (Accessibility) |
| Background Operation | ✓ | ✓ (Limited) | ✓ (Very limited) | ✓ (Foreground only) |

### Version-Specific Bypasses

The payload generator includes specific bypasses for newer Android versions:

**Android 10 (API 29) Bypasses**:
- Scoped storage workarounds
- Background location access techniques
- Hidden API access methods

**Android 11-12 (API 30-31) Bypasses**:
- Package visibility adaptations
- Storage access framework navigation
- One-time permission handling

**Android 13 (API 33) Bypasses**:
- Notification permission workarounds
- More restrictive intents handling
- Background sensor access techniques

**Android 14-15 (API 34-35) Bypasses**:
- Full screen intent restrictions workaround
- Background process limitations bypass
- Partial screen access solutions
- Foreground service type restrictions handling