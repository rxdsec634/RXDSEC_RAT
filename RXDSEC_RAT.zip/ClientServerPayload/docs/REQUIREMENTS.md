# RXDSEC RAT Requirements

This document lists all the dependencies required for the RXDSEC RAT project.

## Server Dependencies

### Core Web Framework
- **Flask** (2.3.3+): Web framework for building the control panel
- **Flask-Login** (0.6.3+): User authentication and session management
- **Flask-SQLAlchemy** (3.1.1+): ORM integration for database operations
- **SQLAlchemy** (2.0.25+): Database ORM
- **gunicorn** (21.2.0+): WSGI HTTP server for production deployment
- **Werkzeug** (2.3.7+): WSGI web application library
- **email-validator** (2.1.0+): Email validation library

### Database Drivers
- **psycopg2-binary** (2.9.7+): PostgreSQL database adapter

### Security and Encryption
- **cryptography** (41.0.5+): Cryptographic operations and secure protocols
- **PyJWT** (2.8.0+): JSON Web Token implementation
- **bcrypt** (4.1.2+): Password hashing

### APK Analysis and Manipulation
- **androguard** (3.4.0+): Android APK analysis
- **apkutils3** (1.0.0+): APK manipulation utilities

### Network and API
- **requests** (2.31.0+): HTTP client library
- **websockets** (11.0.3+): WebSocket implementation
- **python-socketio** (5.10.0+): Socket.IO implementation
- **Flask-SocketIO** (5.3.6+): Socket.IO integration with Flask

### Utility Libraries
- **python-dotenv** (1.0.0+): Environment variable management
- **Pillow** (10.1.0+): Image processing
- **pycryptodomex** (3.19.0+): Advanced cryptographic functions
- **jsonschema** (4.20.0+): JSON Schema validation

## Client Dependencies

### Core Requirements
- **Python** (3.6+): Programming language
- **requests**: HTTP client library for API communication
- **cryptography**: For secure communications

### Android-Specific (via Termux)
- **android-permissions**: Android permissions management

### Optional Platform-Specific Dependencies
- **pywin32** (Windows): Windows API access
- **AppKit** (macOS): macOS API access

## Development and Testing
- **pytest**: Testing framework
- **black**: Code formatter
- **flake8**: Linter
- **coverage**: Code coverage tool

## Installation Instructions

To install server dependencies on your development or production server:

```bash
# Using pip
pip install Flask Flask-Login Flask-SQLAlchemy SQLAlchemy gunicorn Werkzeug \
    email-validator psycopg2-binary cryptography PyJWT bcrypt androguard \
    apkutils3 requests websockets python-socketio Flask-SocketIO python-dotenv \
    Pillow pycryptodomex jsonschema

# Or if you have access to the project directory
pip install -r requirements.txt
```

To install the minimal client dependencies on an Android device (via Termux):

```bash
pkg update
pkg install python
pip install requests cryptography
```

## Environment Setup

### Required Environment Variables
- `SESSION_SECRET`: Secret key for session encryption
- `DATABASE_URL`: Database connection URI
- `DEBUG`: Enable/disable debug mode (True/False)

### Optional Environment Variables
- `BIND_ADDRESS`: IP address to bind the server to (default: 0.0.0.0)
- `PORT`: Server port (default: 5000)
- `LOG_LEVEL`: Logging level (default: INFO)
- `UPLOAD_FOLDER`: Path for file uploads (default: ./data/uploads)
- `MAX_CONTENT_LENGTH`: Maximum file upload size in bytes