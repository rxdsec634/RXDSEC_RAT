# RXDSEC RAT Usage Guide

This document provides comprehensive instructions for using the RXDSEC RAT system, covering both the web-based control panel and client components.

## Table of Contents
- [Getting Started](#getting-started)
- [User Management](#user-management)
- [Device Management](#device-management)
- [Command Execution](#command-execution)
- [File Management](#file-management)
- [Surveillance Features](#surveillance-features)
- [APK Binding](#apk-binding)
- [Security Best Practices](#security-best-practices)
- [Troubleshooting](#troubleshooting)

## Getting Started

### First Login

1. After installation, access the web interface at `http://your-server:5000`
2. Log in with default credentials:
   - Username: `admin`
   - Password: `adminpassword`
3. You will be prompted to change the default password
4. After changing your password, you'll be redirected to the dashboard

### Dashboard Overview

The dashboard provides a comprehensive view of:
- **Connected Devices**: A list of all registered Android/client devices
- **Recent Activities**: Latest commands, file transfers, and surveillance events
- **System Status**: Server health, database status, and uptime information
- **Quick Actions**: Shortcuts for common operations

## User Management

### Creating New Users

1. Navigate to **Settings** > **User Management**
2. Click **Add New User**
3. Fill in required information:
   - Username
   - Email address
   - Password
   - User role (Admin or Operator)
4. Click **Create User**

### User Roles

- **Admin**: Full access to all features and settings
- **Operator**: Can manage devices and execute commands, but cannot modify system settings

### Changing Passwords

1. Go to **Settings** > **My Profile**
2. Click **Change Password**
3. Enter your current password and new password
4. Click **Update Password**

## Device Management

### Device Registration

Devices are registered automatically when a client connects for the first time. You can also manually pre-register a device:

1. Go to **Devices** > **Register New Device**
2. Generate a device ID or enter a custom one
3. Provide an optional device name
4. Click **Register Device**

### Device Information

For each connected device, the following information is displayed:
- **Device ID**: Unique identifier
- **Name**: User-assigned name (if any)
- **Android Version**: OS version and API level
- **Model/Manufacturer**: Device hardware details
- **IP Address**: Current IP address
- **Status**: Online/Offline
- **Last Seen**: Timestamp of last connection
- **Root Status**: Whether the device is rooted/has elevated privileges

### Device Settings

To configure device-specific settings:
1. Select a device from the dashboard
2. Click **Device Settings**
3. Adjust available options:
   - **Hide App Icon**: Toggle visibility in launcher
   - **Prevent Uninstall**: Enable protection against removal
   - **Device Name**: Set a friendly name
   - **Connection Interval**: Heartbeat frequency

## Command Execution

### Running Shell Commands

1. Select a device from the dashboard
2. Go to the **Commands** tab
3. Enter a command in the input field
4. Select command type (shell, app execution, etc.)
5. Click **Send Command**

### Command Types

- **Shell**: Execute shell commands (requires appropriate permissions)
- **App**: Launch an application
- **URL**: Open a URL in the default browser
- **SMS**: Send an SMS message
- **USSD**: Execute USSD codes
- **Text Input**: Send text input to the current application

### Viewing Command History

1. Select a device from the dashboard
2. Go to the **Commands** tab
3. Scroll through the command history
4. Each command shows:
   - Command text
   - Execution status
   - Result or error message
   - Timestamp

## File Management

### Uploading Files to Device

1. Select a device from the dashboard
2. Go to the **Files** tab
3. Click **Upload to Device**
4. Select a file and specify the destination path
5. Click **Upload**

### Downloading Files from Device

1. Select a device from the dashboard
2. Go to the **Files** tab
3. Navigate to the desired directory
4. Select files to download
5. Click **Download Selected**

### File Browser

The file browser allows you to:
- Navigate the device's file system
- Create, rename, and delete files and directories
- View file properties
- Preview text and image files

## Surveillance Features

### Screen Capture

1. Select a device from the dashboard
2. Go to the **Screen** tab
3. Click **Capture Screenshot** for a single image
4. Click **Start Stream** for continuous capture

### Camera Access

1. Select a device from the dashboard
2. Go to the **Camera** tab
3. Select camera (front or back)
4. Click **Capture Photo** or **Start Video**

### Microphone Recording

1. Select a device from the dashboard
2. Go to the **Microphone** tab
3. Set recording duration
4. Click **Start Recording**
5. After completion, download the recording

### SMS Monitoring

1. Select a device from the dashboard
2. Go to the **SMS** tab
3. View all collected messages
4. Filter by contact or content
5. Click **Refresh** to update

### Call Logging

1. Select a device from the dashboard
2. Go to the **Calls** tab
3. View incoming, outgoing, and missed calls
4. Click on a call to see details and recordings (if available)

### Contact Collection

1. Select a device from the dashboard
2. Go to the **Contacts** tab
3. Browse extracted contacts
4. Search or filter by name or number

### Location Tracking

1. Select a device from the dashboard
2. Go to the **Location** tab
3. View current location on map
4. Set tracking interval
5. View location history

### Keylogging

1. Select a device from the dashboard
2. Go to the **Keylogger** tab
3. Enable keylogging
4. View captured keystrokes organized by application

## APK Binding

### Creating a Bound APK

1. Go to **Tools** > **APK Binding**
2. Upload a legitimate APK file
3. Configure binding options:
   - **Persistence Method**: How the payload persists after reboot
   - **Launch Behavior**: When the payload activates
   - **Anti-Detection Features**: Which evasion techniques to employ
   - **Surveillance Capabilities**: Which monitoring features to include
4. Click **Generate Bound APK**
5. Wait for the process to complete
6. Download the modified APK

### Installing Bound APK

1. Transfer the bound APK to the target device
2. Enable "Install from unknown sources" in device settings
3. Install the application
4. Launch the application to activate the payload
5. The device should appear in your dashboard

## Security Best Practices

### Server Security

1. **Use HTTPS**: Always configure SSL/TLS for production
2. **Change Default Credentials**: Immediately after installation
3. **Limit Access**: Use firewalls to restrict access to the server
4. **Regular Updates**: Keep the system and dependencies updated
5. **Logging**: Enable detailed logging for security monitoring

### Operational Security

1. **Use Strong Passwords**: For all user accounts
2. **Regular Backups**: Of the database and configuration
3. **Session Management**: Limit session duration
4. **IP Restrictions**: Limit login attempts and consider IP whitelisting
5. **Command Auditing**: Review command history regularly

## Troubleshooting

### Common Issues

#### Server-Side Issues

1. **Database Connection Errors**
   - Check database connection string
   - Verify database service is running
   - Ensure user permissions are correct

2. **Server Won't Start**
   - Check for port conflicts
   - Verify dependencies are installed
   - Check for syntax errors in configuration files

3. **Web Interface is Slow**
   - Optimize database with indexes
   - Increase server resources
   - Check for long-running queries

#### Client-Side Issues

1. **Client Not Connecting**
   - Verify network connectivity
   - Check server URL is correct
   - Ensure firewalls allow the connection

2. **Permissions Issues**
   - Verify app has necessary Android permissions
   - For advanced features, ensure device is rooted
   - Check Android version compatibility

3. **Commands Failing**
   - Check command syntax
   - Verify device supports the command
   - Check for permission issues

### Getting Help

If you encounter issues not covered in this guide:

1. Check the logs:
   - Server logs: `logs/server.log`
   - Client logs: In the device detail page

2. Consult the [Troubleshooting FAQ](./TROUBLESHOOTING.md)

3. Join the community on Telegram: [@Rxdsec](https://t.me/rxdsec)

---

## Legal Disclaimer

This tool is designed for legitimate security research, ethical penetration testing, and device monitoring with explicit consent. Unauthorized use is illegal and strictly prohibited. The developers assume no liability for misuse of this software.