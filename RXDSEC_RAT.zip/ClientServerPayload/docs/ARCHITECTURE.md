# RXDSEC RAT Architecture

This document provides an overview of the RXDSEC RAT system architecture, explaining the components, communication flow, and implementation details.

## System Overview

RXDSEC RAT follows a client-server architecture:

1. **Server Component**: A web-based control panel built with Flask that manages devices, stores data, and provides a user interface.

2. **Client Component**: A Python-based agent that runs on target devices (primarily Android but with cross-platform support) and provides remote access capabilities.

3. **Communication Layer**: A secure protocol for transmitting commands, data, and surveillance information between clients and the server.

## Architecture Diagram

```
+------------------+                      +------------------+
|                  |                      |                  |
|  Control Panel   |                      |  Target Device   |
|  (Web Interface) |                      |  (Android/Other) |
|                  |                      |                  |
+--------+---------+                      +---------+--------+
         |                                          |
         |                                          |
+--------v---------+     HTTPS/WSS          +-------v--------+
|                  +<--------------------->>+                 |
|  Flask Server    |  Encrypted Commands    |  Client Agent   |
|  (API Endpoints) +---------------------->>+  (Python-based) |
|                  |   Encrypted Data       |                 |
+--------+---------+                       +-----------------+
         |
         |
+--------v---------+
|                  |
|  Database        |
|  (PostgreSQL)    |
|                  |
+------------------+
```

## Component Details

### Server Component

#### Core Technologies:
- **Flask**: Web framework for the backend
- **SQLAlchemy**: ORM for database interactions
- **Flask-Login**: Authentication management
- **WebSockets**: Real-time communications
- **Gunicorn**: WSGI HTTP server for production

#### Key Modules:
1. **User Management**: Authentication, authorization, and session handling
2. **Device Management**: Device registration, tracking, and configuration
3. **Command Processing**: Command queuing, execution, and result handling
4. **File Transfer**: Secure file upload and download capabilities
5. **Surveillance Module**: Processing and storing surveillance data
6. **APK Binding**: Tools for injecting payloads into legitimate APKs
7. **Database Models**: SQLAlchemy models for all data entities
8. **Security Layer**: Encryption, token validation, and secure communications

#### Database Schema:
- **User**: Admin and operator accounts
- **Device**: Connected client information
- **Command**: Executed commands and results
- **FileTransfer**: File transfer records
- **SmsMessage**: Collected SMS messages
- **CallLog**: Phone call records
- **Contact**: Device contacts
- **Location**: GPS tracking data
- **KeylogEntry**: Captured keystrokes

### Client Component

#### Core Technologies:
- **Python**: Primary programming language
- **Requests**: HTTP client for API communication
- **Cryptography**: Secure communication tools
- **Platform-specific libraries**: For Android, Windows, Linux, macOS compatibility

#### Key Modules:
1. **Core Client**: Main client class managing connections and operations
2. **AntiDetectionMixin**: Anti-emulator and anti-debugging capabilities
3. **SurveillanceFeaturesMixin**: Camera, microphone, SMS, call logging capabilities
4. **CommandExecutor**: Processes and executes received commands
5. **FileManager**: Handles file system operations and transfers
6. **DeviceInfo**: Collects and reports device information
7. **PersistenceManager**: Implements startup and persistence mechanisms
8. **EncryptionLayer**: Handles secure communications

#### Key Features:
1. **Cross-Platform Compatibility**: Works on Android (primary), Windows, Linux, and macOS
2. **Anti-Detection**: Multiple techniques to avoid detection
3. **Command Execution**: Shell command and application execution
4. **File Operations**: Browse, upload, and download files
5. **Surveillance**: Camera, microphone, SMS, calls, contacts, location, keylogging
6. **Persistence**: Maintains access across device reboots
7. **Screen Capture**: Real-time screen viewing capabilities

### Communication Protocol

#### Authentication:
1. **Device Registration**:
   - Device generates unique ID on first run
   - Sends registration request with device info
   - Server issues authentication token

2. **Ongoing Authentication**:
   - All requests include device ID and token
   - HMAC validation of request integrity
   - Token refresh mechanism for long-term persistence

#### Data Transport:
1. **Command Channel**:
   - REST API for command queue and results
   - Periodic polling or WebSocket for real-time operations
   - Commands encrypted with AES-256-GCM

2. **File Transfer**:
   - Chunked uploads/downloads for large files
   - SHA-256 hash verification
   - Resume capability for interrupted transfers

3. **Surveillance Data**:
   - Compressed and encrypted transmission
   - Optional throttling for bandwidth control
   - Metadata inclusion for context

## Security Implementation

### Encryption:
- **End-to-End Encryption**: All communications encrypted with AES-256-GCM
- **Key Derivation**: PBKDF2 with high iteration count
- **Message Authentication**: HMAC-SHA256 for message integrity
- **Perfect Forward Secrecy**: Key rotation mechanism

### Anti-Detection:
1. **Emulator Detection**:
   - Build property analysis
   - Hardware characteristic verification
   - Timing-based detection

2. **Debugger Evasion**:
   - Debug flag checking
   - Tracer detection
   - Timing anomaly detection
   - Memory pattern analysis

3. **Visibility Control**:
   - Package hiding from launcher
   - Removal from recent apps
   - Service-based operation

4. **String Encryption**:
   - Obfuscated strings to avoid signature detection
   - Dynamic decryption at runtime

### Persistence:
1. **Android Mechanisms**:
   - Job schedulers
   - Broadcast receivers
   - Boot receivers
   - System service masquerading

2. **Cross-Platform Methods**:
   - Registry entries (Windows)
   - Launch agents (macOS)
   - Systemd services (Linux)
   - Scheduled tasks

## APK Binding Process

The APK binding process injects the RXDSEC RAT payload into legitimate applications:

1. **Decompilation**:
   - Androguard and ApkTool for APK analysis and extraction

2. **Injection Points**:
   - Main activity hooking
   - Service injection
   - Broadcast receiver addition

3. **Manifest Modifications**:
   - Permission addition
   - Component registration
   - Boot receiver integration

4. **Code Injection**:
   - Java/Smali code injection
   - Method hooking
   - Native library loading

5. **Recompilation**:
   - Code reassembly
   - Resource repackaging
   - APK signing

## Scalability Considerations

1. **Horizontal Scaling**:
   - Stateless API design
   - Database connection pooling
   - Load balancer compatibility

2. **Performance Optimization**:
   - Efficient database indexing
   - Query optimization
   - Caching strategies

3. **Resource Management**:
   - Connection throttling
   - File transfer rate limiting
   - Database query timeout handling

## Future Architecture Enhancements

1. **Distributed Command & Control**:
   - Multiple server nodes
   - Traffic distribution
   - Geographic redundancy

2. **Enhanced Encryption**:
   - Post-quantum cryptography options
   - Multiple encryption layers
   - Custom protocol obfuscation

3. **Advanced Anti-Detection**:
   - Machine learning-based environment detection
   - Behavioral adaptation
   - Polymorphic code techniques

4. **Expanded Platform Support**:
   - iOS compatibility
   - Smart device integration
   - IoT device support

## Development and Testing

1. **Development Environment**:
   - Python virtual environments
   - Docker containers for isolation
   - Consistent dependency management

2. **Testing Framework**:
   - Unit tests for core functionality
   - Integration tests for API endpoints
   - End-to-end tests for complete workflows

3. **Security Testing**:
   - Regular security audits
   - Penetration testing
   - Code analysis tools