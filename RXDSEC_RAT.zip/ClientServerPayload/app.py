import os
import json
import logging
from flask import Flask, Response
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from sqlalchemy.orm import DeclarativeBase
from werkzeug.security import generate_password_hash

# Configure logging
logger = logging.getLogger(__name__)

# Set up SQLAlchemy base class
class Base(DeclarativeBase):
    pass

# Initialize SQLAlchemy
db = SQLAlchemy(model_class=Base)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev_secret_key_change_in_production")

# Use in-memory SQLite database for MVP
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Set max content length to 20MB to support file uploads and media content
app.config['MAX_CONTENT_LENGTH'] = 20 * 1024 * 1024  # 20MB

# Add security headers
@app.after_request
def add_security_headers(response):
    if isinstance(response, Response):
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'SAMEORIGIN'
        response.headers['X-XSS-Protection'] = '1; mode=block'
        response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
        response.headers['Content-Security-Policy'] = "default-src 'self'; style-src 'self' https://cdn.replit.com https://cdn.jsdelivr.net 'unsafe-inline'; script-src 'self' https://cdn.jsdelivr.net 'unsafe-inline'; img-src 'self' data:; media-src 'self' data:;"
    return response

# Custom Jinja filters
@app.template_filter('tojson')
def to_json(value):
    """Convert string to JSON object for template usage"""
    try:
        if isinstance(value, str):
            return json.loads(value)
        return value
    except (json.JSONDecodeError, TypeError):
        return {}

# Add filesize formatting filter
@app.template_filter('format_filesize')
def format_filesize(num_bytes):
    """Format file size in bytes to human-readable format"""
    if num_bytes is None or num_bytes == 0:
        return "0 B"
    units = ['B', 'KB', 'MB', 'GB', 'TB']
    i = 0
    while num_bytes >= 1024 and i < len(units) - 1:
        num_bytes /= 1024
        i += 1
    return f"{num_bytes:.2f} {units[i]}"

# Initialize database with the app
db.init_app(app)

# Configure flask-login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    from models import User
    return User.query.get(int(user_id))

# Create all tables and initialize demo user
with app.app_context():
    # Import models after db is defined to avoid circular imports
    from models import User, Device, Command, FileTransfer
    
    db.create_all()
    
    # Create admin user if it doesn't exist
    if not User.query.filter_by(username='admin').first():
        admin_user = User(
            username='admin',
            email='admin@example.com',
            password_hash=generate_password_hash('adminpassword')
        )
        db.session.add(admin_user)
        db.session.commit()
        logger.info("Admin user created")

# Add template context processor to provide current time
@app.context_processor
def inject_now():
    from datetime import datetime
    return {'now': datetime.utcnow}

# Import and register routes
from routes import *
